=== Website Stylekit ===
Contributors: rinothecoder
Tags: elementor, design tokens, import, export, variables
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Import and export Elementor V4 design token variables as JSON.

== Description ==

Website Stylekit is the bridge between websitestylekit.com and your page builder. Build your design system once — your colors, sizes, and fonts — and import it straight into Elementor V4 global variables.

**Import**
* Import color variables from websitestylekit.com JSON
* Import font size variables from CSS clamp values
* Three import modes: smart merge, replace all, or add as copy

**Export**
* Export colors, sizes, and fonts as clean JSON or raw Elementor format
* Filter by variable type

**Utilities**
* Reorder variables — groups by type and assigns clean sequential order numbers

== Installation ==

1. Download the zip file
2. In WordPress, go to Plugins → Add New → Upload Plugin
3. Upload the zip and activate
4. Find Website Stylekit in the left menu

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
First release.
