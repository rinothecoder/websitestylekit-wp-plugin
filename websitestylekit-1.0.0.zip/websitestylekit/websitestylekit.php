<?php
/**
 * Plugin Name: Website Stylekit
 * Plugin URI: https://rinodeboer.com
 * Description: Import and export Elementor V4 design token variables as JSON.
 * Version: 1.0.0
 * Author: Rino de Boer
 * Author URI: https://rinodeboer.com
 * License: GPL v2 or later
 * Text Domain: websitestylekit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WSK_VERSION', '1.0.0' );
define( 'WSK_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WSK_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main plugin class.
 */
class Website_Stylekit {

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_ajax_wsk_export_variables', array( $this, 'ajax_export_variables' ) );
		add_action( 'wp_ajax_wsk_import_variables', array( $this, 'ajax_import_variables' ) );
		add_action( 'wp_ajax_wsk_reorder_variables', array( $this, 'ajax_reorder_variables' ) );
	}

	/**
	 * Add menu item under Settings.
	 */
	public function add_admin_menu() {
		$menu_icon_svg = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 120 120"><path fill="#a7aaad" d="M83 0C103.435 0 120 16.5655 120 37V83C120 103.435 103.435 120 83 120H37C16.5655 120 0 103.435 0 83V37C0 16.5655 16.5655 0 37 0H83ZM101.04 32.9424C96.6498 29.4405 90.2472 27.9148 84.5342 29.002C75.9223 30.6259 70.8418 36.5007 70.8418 44.832C70.8419 52.4289 73.6003 55.7611 84.6182 61.4658C91.2881 64.9254 93.3423 67.1995 93.3564 71.125C93.3705 80.4447 80.8613 84.1305 72.9951 77.127C68.7736 73.3708 67.5633 69.967 59.7676 40.0449C57.7835 32.3915 58.3601 32.9424 52.2676 32.9424C50.0315 32.9424 48.7026 32.7792 47.7598 33.1836L47.3164 33.0615L47.1846 33.5439C45.9052 34.6532 45.3204 37.6377 43.2754 45.5098C41.6853 51.6383 39.5036 59.9697 38.4482 63.9941C37.3796 68.0297 36.5081 71.5014 36.5068 71.7178C36.5068 73.0027 35.6904 71.4354 35.0713 68.9219C30.105 49.0863 26.2499 34.2331 25.9248 33.7188C25.319 32.7728 14.4705 32.8431 14.3291 33.7891C14.2589 34.3264 17.2703 46.2028 24.6719 74.458C27.6124 85.7247 28.1622 87.533 28.7812 88.084C29.7808 88.9594 40.5032 89.0728 41.5586 88.2256C42.1363 87.7423 47.4826 69.0198 50.958 55.3096C51.9571 51.3699 52.267 50.9181 52.6328 52.8525C53.9134 59.7436 58.3042 75.1498 59.8662 78.2705C66.9022 92.3348 87.6442 95.8649 98.6201 84.8506C104.938 78.4962 106.655 68.2587 102.546 61.2266C100.843 58.3318 98.1692 56.1995 91.7246 52.6553C82.8172 47.7553 80.4113 44.5209 82.6768 40.4541C85.0128 36.3029 90.6128 36.3458 95.6504 40.5537C98.2675 42.7423 98.17 42.7845 101.505 38.0684C103.602 35.1313 103.587 34.9615 101.04 32.9424Z"/></svg>' );
		add_menu_page(
			__( 'Website Stylekit', 'websitestylekit' ),
			__( 'Website Stylekit', 'websitestylekit' ),
			'manage_options',
			'website-stylekit',
			array( $this, 'render_admin_page' ),
			$menu_icon_svg
		);
	}

	/**
	 * Enqueue CSS and JS on our admin page only.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( 'toplevel_page_website-stylekit' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'wsk-admin',
			WSK_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			WSK_VERSION
		);

		wp_enqueue_script(
			'wsk-admin',
			WSK_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			WSK_VERSION,
			true
		);

		wp_localize_script( 'wsk-admin', 'wskData', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'wsk_nonce' ),
		) );
	}

	/**
	 * Get the active Elementor kit post ID.
	 */
	private function get_kit_id() {
		$kit_id = get_option( 'elementor_active_kit' );

		if ( ! $kit_id ) {
			return false;
		}

		return (int) $kit_id;
	}

	/**
	 * Read raw variables data from the kit post meta.
	 */
	private function get_raw_variables() {
		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			return new WP_Error( 'no_kit', 'No active Elementor kit found.' );
		}

		$meta = get_post_meta( $kit_id, '_elementor_global_variables', true );

		if ( empty( $meta ) ) {
			return new WP_Error( 'no_variables', 'No variables found. Make sure you have created variables in Elementor.' );
		}

		if ( is_string( $meta ) ) {
			$meta = json_decode( $meta, true );
		}

		if ( ! is_array( $meta ) || ! isset( $meta['data'] ) ) {
			return new WP_Error( 'invalid_data', 'Variable data is in an unexpected format.' );
		}

		return $meta;
	}

	/**
	 * Which variable types to include based on the filter.
	 */
	private function get_type_filter( $filter ) {
		$types = array(
			'colors' => array( 'global-color-variable' ),
			'sizes'  => array( 'global-size-variable', 'global-custom-size-variable' ),
			'fonts'  => array( 'global-font-variable' ),
			'all'    => array( 'global-color-variable', 'global-size-variable', 'global-custom-size-variable', 'global-font-variable' ),
		);

		return $types[ $filter ] ?? $types['all'];
	}

	/**
	 * Extract a clean, readable value from Elementor's nested storage format.
	 */
	private function extract_clean_value( $value, $type ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		$inner = $value['value'] ?? $value;

		// Colors: { "$$type": "color", "value": "#hex" }
		if ( 'global-color-variable' === $type ) {
			return is_array( $inner ) ? ( $inner['value'] ?? $inner ) : $inner;
		}

		// Sizes: { "$$type": "size", "value": { "size": 16, "unit": "px" } }
		if ( in_array( $type, array( 'global-size-variable', 'global-custom-size-variable' ), true ) ) {
			if ( is_array( $inner ) && isset( $inner['unit'] ) ) {
				if ( 'custom' === $inner['unit'] ) {
					// Clamp or other custom value.
					return $inner['size'] ?? '';
				}
				if ( 'auto' === $inner['unit'] ) {
					return 'auto';
				}
				return ( $inner['size'] ?? '0' ) . $inner['unit'];
			}
			return $inner;
		}

		// Fonts: { "$$type": "string", "value": "Inter" }
		if ( 'global-font-variable' === $type ) {
			return is_array( $inner ) ? ( $inner['value'] ?? $inner ) : $inner;
		}

		return $inner;
	}

	/**
	 * Export variables as clean JSON.
	 */
	public function export_clean_variables( $filter = 'all' ) {
		$raw = $this->get_raw_variables();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$allowed_types = $this->get_type_filter( $filter );
		$result = array();

		foreach ( $raw['data'] as $id => $variable ) {
			if ( ! empty( $variable['deleted_at'] ) ) {
				continue;
			}

			$type = $variable['type'] ?? '';

			if ( ! in_array( $type, $allowed_types, true ) ) {
				continue;
			}

			$result[ $id ] = array(
				'type'  => $type,
				'label' => $variable['label'] ?? '',
				'value' => $this->extract_clean_value( $variable['value'] ?? '', $type ),
				'order' => $variable['order'] ?? 0,
			);
		}

		uasort( $result, function( $a, $b ) {
			return ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 );
		} );

		return $result;
	}

	/**
	 * Export the full raw variable data (mirrors Elementor's storage).
	 */
	public function export_raw_variables( $filter = 'all' ) {
		$raw = $this->get_raw_variables();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$allowed_types = $this->get_type_filter( $filter );
		$clean_data = array();

		foreach ( $raw['data'] as $id => $variable ) {
			if ( ! empty( $variable['deleted_at'] ) ) {
				continue;
			}

			$type = $variable['type'] ?? '';

			if ( in_array( $type, $allowed_types, true ) ) {
				$clean_data[ $id ] = $variable;
			}
		}

		return array(
			'data'      => $clean_data,
			'watermark' => $raw['watermark'] ?? 0,
			'version'   => $raw['version'] ?? 1,
		);
	}

	/**
	 * AJAX handler for exporting variables.
	 */
	public function ajax_export_variables() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$format = isset( $_POST['format'] ) ? sanitize_text_field( wp_unslash( $_POST['format'] ) ) : 'clean';
		$format = in_array( $format, array( 'clean', 'raw' ), true ) ? $format : 'clean';

		$filter = isset( $_POST['filter'] ) ? sanitize_text_field( wp_unslash( $_POST['filter'] ) ) : 'all';
		$filter = in_array( $filter, array( 'all', 'colors', 'sizes', 'fonts' ), true ) ? $filter : 'all';

		if ( 'raw' === $format ) {
			$result = $this->export_raw_variables( $filter );
		} else {
			$result = $this->export_clean_variables( $filter );
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/**
	 * Generate a random Elementor-style variable ID.
	 */
	private function generate_variable_id() {
		return 'e-gv-' . substr( md5( wp_generate_uuid4() ), 0, 7 );
	}

	/**
	 * Convert a human-readable name to a valid Elementor label.
	 * "Primary Brand 1" becomes "primary-brand-1".
	 */
	private function name_to_label( $name ) {
		$label = strtolower( trim( $name ) );
		$label = preg_replace( '/[^a-z0-9]+/', '-', $label );
		$label = trim( $label, '-' );

		// Max 50 chars.
		if ( strlen( $label ) > 50 ) {
			$label = substr( $label, 0, 50 );
		}

		return $label;
	}

	/**
	 * Parse a CSS :root block into an array of variable name => value pairs.
	 * Input: ":root { --font-size-heading-1: clamp(...); --font-size-body: 1rem; }"
	 */
	private function parse_css_root( $css_string ) {
		$variables = array();

		// Extract content inside :root { ... }
		if ( preg_match( '/:root\s*\{([^}]+)\}/', $css_string, $match ) ) {
			$content = $match[1];
		} else {
			// Maybe they pasted just the properties without the :root wrapper.
			$content = $css_string;
		}

		// Match each --variable-name: value;
		preg_match_all( '/--([a-zA-Z0-9_-]+)\s*:\s*(.+?)\s*;/', $content, $matches, PREG_SET_ORDER );

		foreach ( $matches as $index => $m ) {
			$variables[] = array(
				'id'    => $this->generate_variable_id(),
				'label' => $this->name_to_label( $m[1] ),
				'value' => trim( $m[2] ),
				'order' => $index + 1,
			);
		}

		return $variables;
	}

	/**
	 * Detect the format of the pasted input and normalize it into an array of variables.
	 * Supports: JSON (colors/sizes), CSS :root (sizes), and clean export format.
	 */
	private function parse_import_input( $input, $var_type = 'colors' ) {
		$input = trim( $input );

		// Check if it's a CSS :root block (contains -- custom properties).
		if ( preg_match( '/(:root\s*\{|--[a-zA-Z0-9_-]+\s*:)/', $input ) ) {
			$variables = $this->parse_css_root( $input );

			if ( empty( $variables ) ) {
				return new WP_Error( 'parse_failed', 'Could not parse any CSS custom properties from the input.' );
			}

			return $variables;
		}

		// Try to parse as JSON.
		$data = json_decode( $input, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return new WP_Error( 'invalid_input', 'Could not parse the input. Paste valid JSON or CSS custom properties (:root block).' );
		}

		// Format 1: Websitestylekit.com color format - array of { name, hex }
		if ( isset( $data[0] ) && isset( $data[0]['name'] ) && isset( $data[0]['hex'] ) ) {
			$variables = array();
			foreach ( $data as $index => $item ) {
				$variables[] = array(
					'id'    => $this->generate_variable_id(),
					'label' => $this->name_to_label( $item['name'] ),
					'value' => $item['hex'],
					'order' => $index + 1,
				);
			}
			return $variables;
		}

		// Format 2: Clean export format - object with e-gv- keys.
		if ( is_array( $data ) && ! isset( $data[0] ) ) {
			$first_key = array_key_first( $data );

			if ( $first_key && strpos( $first_key, 'e-gv-' ) === 0 && isset( $data[ $first_key ]['label'] ) ) {
				$variables = array();
				foreach ( $data as $id => $item ) {
					$variables[] = array(
						'id'    => $id,
						'label' => $item['label'],
						'value' => $item['value'],
						'order' => $item['order'] ?? 0,
					);
				}
				return $variables;
			}
		}

		return new WP_Error( 'unknown_format', 'Unrecognized format. Supported: websitestylekit.com JSON (colors), CSS :root block (sizes), or clean export from this plugin.' );
	}

	/**
	 * Parse a size value string into Elementor's storage format.
	 * "1rem" => { "size": 1, "unit": "rem" }
	 * "clamp(...)" => { "size": "clamp(...)", "unit": "custom" }
	 */
	private function parse_size_for_storage( $value ) {
		$value = trim( $value );

		// Clamp, calc, or other function-based values are stored as custom.
		if ( preg_match( '/^(clamp|calc|min|max|var)\s*\(/', $value ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => $value,
					'unit' => 'custom',
				),
			);
		}

		// "auto"
		if ( 'auto' === strtolower( $value ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => '',
					'unit' => 'auto',
				),
			);
		}

		// Simple numeric value with unit: "16px", "2rem", "1.5em", "50%"
		if ( preg_match( '/^(-?\d*\.?\d+)\s*(%|[a-z]+)$/i', $value, $m ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => $m[1] + 0, // Cast to number.
					'unit' => strtolower( $m[2] ),
				),
			);
		}

		// Just a number with no unit, default to px.
		if ( is_numeric( $value ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => $value + 0,
					'unit' => 'px',
				),
			);
		}

		// Fallback: treat as custom.
		return array(
			'$$type' => 'size',
			'value'  => array(
				'size' => $value,
				'unit' => 'custom',
			),
		);
	}

	/**
	 * Build a lookup of existing active variable labels to their IDs, filtered by type.
	 */
	private function get_existing_label_map( $existing, $elementor_types = array() ) {
		$map = array();

		foreach ( $existing as $id => $var ) {
			if ( isset( $var['deleted_at'] ) ) {
				continue;
			}
			if ( ! empty( $elementor_types ) && ! in_array( $var['type'] ?? '', $elementor_types, true ) ) {
				continue;
			}
			$map[ strtolower( $var['label'] ?? '' ) ] = $id;
		}

		return $map;
	}

	/**
	 * Find the highest order number among ALL active variables (colors, sizes, fonts, etc.).
	 */
	private function get_max_order( $existing ) {
		$max = 0;

		foreach ( $existing as $var ) {
			if ( isset( $var['deleted_at'] ) ) {
				continue;
			}
			$order = $var['order'] ?? 0;
			if ( $order > $max ) {
				$max = $order;
			}
		}

		return $max;
	}

	/**
	 * Make a label unique by appending -copy, -copy-2, etc.
	 */
	private function make_unique_label( $label, $existing_labels ) {
		if ( ! isset( $existing_labels[ strtolower( $label ) ] ) ) {
			return $label;
		}

		$base = $label . '-copy';
		if ( ! isset( $existing_labels[ strtolower( $base ) ] ) ) {
			return $base;
		}

		$counter = 2;
		while ( isset( $existing_labels[ strtolower( $base . '-' . $counter ) ] ) ) {
			$counter++;
		}

		return $base . '-' . $counter;
	}

	/**
	 * Build the Elementor V2 storage value for a variable based on its type.
	 */
	private function build_elementor_value( $raw_value, $var_type ) {
		if ( 'sizes' === $var_type ) {
			return $this->parse_size_for_storage( $raw_value );
		}

		// Colors.
		return array(
			'$$type' => 'color',
			'value'  => $raw_value,
		);
	}

	/**
	 * Get the Elementor internal type string for a variable type.
	 */
	private function get_elementor_type( $var_type ) {
		$map = array(
			'colors' => 'global-color-variable',
			'sizes'  => 'global-size-variable',
			'fonts'  => 'global-font-variable',
		);

		return $map[ $var_type ] ?? 'global-color-variable';
	}

	/**
	 * Get all Elementor type strings that belong to a variable type (for filtering).
	 */
	private function get_elementor_types_for_filter( $var_type ) {
		$map = array(
			'colors' => array( 'global-color-variable' ),
			'sizes'  => array( 'global-size-variable', 'global-custom-size-variable' ),
			'fonts'  => array( 'global-font-variable' ),
		);

		return $map[ $var_type ] ?? array( 'global-color-variable' );
	}

	/**
	 * Convert parsed variables into Elementor V2 storage format and save.
	 *
	 * Modes:
	 * - "merge"   : Add new variables. If a label already exists, update its value.
	 * - "replace" : Delete all existing variables of this type and import fresh.
	 * - "copy"    : Always add. If a label exists, append -copy to the new one.
	 */
	private function import_variables( $variables, $mode = 'merge', $var_type = 'colors' ) {
		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			return new WP_Error( 'no_kit', 'No active Elementor kit found. Make sure Elementor is installed and active.' );
		}

		// Read existing data.
		$meta = get_post_meta( $kit_id, '_elementor_global_variables', true );
		$existing = array();
		$watermark = 0;

		if ( ! empty( $meta ) ) {
			if ( is_string( $meta ) ) {
				$meta = json_decode( $meta, true );
			}
			if ( is_array( $meta ) ) {
				$existing = $meta['data'] ?? array();
				$watermark = $meta['watermark'] ?? 0;
			}
		}

		$now = gmdate( 'Y-m-d H:i:s' );
		$elementor_type = $this->get_elementor_type( $var_type );
		$elementor_types = $this->get_elementor_types_for_filter( $var_type );
		$label_map = $this->get_existing_label_map( $existing, $elementor_types );
		$imported = 0;
		$updated = 0;

		if ( 'replace' === $mode ) {
			// Soft-delete all existing variables of this type.
			foreach ( $existing as $id => &$var ) {
				if ( isset( $var['type'] ) && in_array( $var['type'], $elementor_types, true ) && ! isset( $var['deleted_at'] ) ) {
					$var['deleted_at'] = $now;
				}
			}
			unset( $var );
			$label_map = array();
		}

		// Determine starting order for new variables.
		$next_order = ( 'replace' === $mode ) ? 1 : $this->get_max_order( $existing ) + 1;

		foreach ( $variables as $variable ) {
			$label = $variable['label'];
			$existing_id = $label_map[ strtolower( $label ) ] ?? null;
			$storage_value = $this->build_elementor_value( $variable['value'], $var_type );

			if ( 'merge' === $mode && $existing_id ) {
				// Update the existing variable's value.
				$existing[ $existing_id ]['value'] = $storage_value;
				$existing[ $existing_id ]['updated_at'] = $now;
				$updated++;

			} elseif ( 'copy' === $mode && $existing_id ) {
				// Add as copy with a unique label.
				$unique_label = $this->make_unique_label( $label, $label_map );
				$new_id = $this->generate_variable_id();

				$existing[ $new_id ] = array(
					'type'       => $elementor_type,
					'label'      => $unique_label,
					'value'      => $storage_value,
					'order'      => $next_order++,
					'created_at' => $now,
					'updated_at' => $now,
				);

				$label_map[ strtolower( $unique_label ) ] = $new_id;
				$imported++;

			} else {
				// New variable (all modes).
				$new_id = $variable['id'] ?? $this->generate_variable_id();
				$order = ( 'replace' === $mode ) ? $variable['order'] : $next_order++;

				$existing[ $new_id ] = array(
					'type'       => $elementor_type,
					'label'      => $label,
					'value'      => $storage_value,
					'order'      => $order,
					'created_at' => $now,
					'updated_at' => $now,
				);

				$label_map[ strtolower( $label ) ] = $new_id;
				$imported++;
			}
		}

		$watermark++;

		$record = array(
			'data'      => $existing,
			'watermark' => $watermark,
			'version'   => 2,
		);

		$result = update_post_meta(
			$kit_id,
			'_elementor_global_variables',
			wp_slash( wp_json_encode( $record ) )
		);

		if ( false === $result ) {
			return new WP_Error( 'save_failed', 'Failed to save variables to the database.' );
		}

		return array(
			'imported' => $imported,
			'updated'  => $updated,
			'total'    => $imported + $updated,
		);
	}

	/**
	 * AJAX handler for importing variables.
	 */
	public function ajax_import_variables() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$json_input = isset( $_POST['json_input'] ) ? sanitize_textarea_field( wp_unslash( $_POST['json_input'] ) ) : '';
		$mode = isset( $_POST['mode'] ) ? sanitize_text_field( wp_unslash( $_POST['mode'] ) ) : 'merge';
		$mode = in_array( $mode, array( 'merge', 'replace', 'copy' ), true ) ? $mode : 'merge';

		$var_type = isset( $_POST['var_type'] ) ? sanitize_text_field( wp_unslash( $_POST['var_type'] ) ) : 'colors';
		$var_type = in_array( $var_type, array( 'colors', 'sizes' ), true ) ? $var_type : 'colors';

		if ( empty( $json_input ) ) {
			wp_send_json_error( 'No input provided.' );
		}

		// Parse and detect format.
		$variables = $this->parse_import_input( $json_input, $var_type );

		if ( is_wp_error( $variables ) ) {
			wp_send_json_error( $variables->get_error_message() );
		}

		if ( empty( $variables ) ) {
			wp_send_json_error( 'No variables found in the input.' );
		}

		// Import into Elementor.
		$result = $this->import_variables( $variables, $mode, $var_type );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/**
	 * Reorder all active variables: group by type, then assign sequential order numbers.
	 * Order: colors first, then fonts, then sizes.
	 */
	public function ajax_reorder_variables() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			wp_send_json_error( 'No active Elementor kit found.' );
		}

		$meta = get_post_meta( $kit_id, '_elementor_global_variables', true );

		if ( empty( $meta ) ) {
			wp_send_json_error( 'No variables found.' );
		}

		if ( is_string( $meta ) ) {
			$meta = json_decode( $meta, true );
		}

		if ( ! is_array( $meta ) || ! isset( $meta['data'] ) ) {
			wp_send_json_error( 'Variable data is in an unexpected format.' );
		}

		$existing = $meta['data'];
		$watermark = $meta['watermark'] ?? 0;

		// Group active variables by type.
		$type_order = array(
			'global-color-variable'       => 1,
			'global-font-variable'        => 2,
			'global-size-variable'        => 3,
			'global-custom-size-variable' => 3,
		);

		$active = array();
		foreach ( $existing as $id => $var ) {
			if ( isset( $var['deleted_at'] ) ) {
				continue;
			}
			$active[ $id ] = $var;
		}

		// Sort by type group first, then by current order within the group.
		uasort( $active, function( $a, $b ) use ( $type_order ) {
			$type_a = $type_order[ $a['type'] ?? '' ] ?? 99;
			$type_b = $type_order[ $b['type'] ?? '' ] ?? 99;

			if ( $type_a !== $type_b ) {
				return $type_a - $type_b;
			}

			return ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 );
		} );

		// Assign fresh sequential order numbers.
		$order = 1;
		$now = gmdate( 'Y-m-d H:i:s' );

		foreach ( $active as $id => $var ) {
			$existing[ $id ]['order'] = $order++;
			$existing[ $id ]['updated_at'] = $now;
		}

		$watermark++;

		$record = array(
			'data'      => $existing,
			'watermark' => $watermark,
			'version'   => 2,
		);

		$result = update_post_meta(
			$kit_id,
			'_elementor_global_variables',
			wp_slash( wp_json_encode( $record ) )
		);

		if ( false === $result ) {
			wp_send_json_error( 'Failed to save.' );
		}

		// Count by type for the summary.
		$counts = array();
		foreach ( $active as $var ) {
			$type = $var['type'] ?? 'unknown';
			$counts[ $type ] = ( $counts[ $type ] ?? 0 ) + 1;
		}

		wp_send_json_success( array(
			'total'  => count( $active ),
			'counts' => $counts,
		) );
	}

	/**
	 * Render the admin page.
	 */
	public function render_admin_page() {
		?>
		<div class="wsk-wrap">

			<header class="wsk-header">
				<div class="wsk-header-inner">
					<div class="wsk-header__left">
						<img
							src="<?php echo esc_url( WSK_PLUGIN_URL . 'assets/img/wsk-icon.svg' ); ?>"
							alt="Website Stylekit"
							class="wsk-header__icon"
							width="28"
							height="28"
						>
						<h1 class="wsk-header__title">Website Stylekit</h1>
						<span class="wsk-header__version">v<?php echo esc_html( WSK_VERSION ); ?></span>
					</div>
					<nav class="wsk-header__nav">
						<a href="#import" class="wsk-header__link wsk-header__link--active" data-tab="import">Import</a>
						<a href="#export" class="wsk-header__link" data-tab="export">Export</a>
						<a href="#about" class="wsk-header__link" data-tab="about">About</a>
						<a href="#changelog" class="wsk-header__link" data-tab="changelog">Changelog</a>
						<?php /* Support tab hidden for now — content preserved, enable by uncommenting the line below */ ?>
						<?php // echo '<a href="#support" class="wsk-header__link" data-tab="support">Support</a>'; ?>
					</nav>
				</div>
			</header>

			<div class="wsk-content">
				<div class="wsk-tab-panel active" data-tab="import">
					<?php $this->render_import_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="export">
					<?php $this->render_export_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="about">
					<?php $this->render_about_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="changelog">
					<?php $this->render_changelog_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="support">
					<?php $this->render_support_tab(); ?>
				</div>
			</div>

		</div>
		<?php
	}

	/**
	 * Render the Export tab.
	 */
	private function render_export_tab() {
		?>
		<div class="wsk-card">
			<h2>Export Variables</h2>
			<p class="wsk-description">Export your Elementor V4 design token variables as JSON.</p>

			<h3 class="wsk-section-label">Variable type</h3>
			<div class="wsk-format-toggle">
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_filter" value="all" checked>
					<span>All variables</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_filter" value="colors">
					<span>Colors only</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_filter" value="sizes">
					<span>Sizes only</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_filter" value="fonts">
					<span>Fonts only</span>
				</label>
			</div>

			<h3 class="wsk-section-label">Output format</h3>
			<div class="wsk-format-toggle">
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_format" value="clean" checked>
					<span>Clean JSON</span>
					<span class="wsk-hint">Label, value and order only</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_format" value="raw">
					<span>Raw Elementor Format</span>
					<span class="wsk-hint">Mirrors how Elementor stores the data</span>
				</label>
			</div>

			<div class="wsk-actions">
				<button id="wsk-export-btn" class="button button-primary">Export Variables</button>
				<button id="wsk-copy-btn" class="button" style="display:none;">Copy to Clipboard</button>
				<button id="wsk-download-btn" class="button" style="display:none;">Download JSON</button>
			</div>

			<div id="wsk-export-result" style="display:none;">
				<h3>Result</h3>
				<textarea id="wsk-export-output" readonly rows="20"></textarea>
			</div>

			<div id="wsk-export-error" class="wsk-error" style="display:none;"></div>
		</div>
		<?php
	}

	/**
	 * Render the Import tab.
	 */
	private function render_import_tab() {
		?>
		<div class="wsk-card">
			<h2>Import your stylekit</h2>
			<p class="wsk-description">Bring your colors and font sizes from <a href="https://websitestylekit.com" target="_blank">websitestylekit.com</a> straight into Elementor. Pick what you want to import below, then paste and go.</p>

			<h3 class="wsk-section-label">What are you importing?</h3>
			<div class="wsk-format-toggle">
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_var_type" value="colors" checked>
					<span>Colors</span>
					<span class="wsk-hint">On websitestylekit.com, click "Copy JSON" on your color palette and paste it below.</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_var_type" value="sizes">
					<span>Font sizes</span>
					<span class="wsk-hint">On websitestylekit.com, click "Copy CSS clamp" on your typography and paste it below.</span>
				</label>
			</div>

			<textarea id="wsk-import-input" rows="16" placeholder='Paste your colors or font sizes here.'></textarea>

			<h3 class="wsk-section-label">How should we handle existing variables?</h3>
			<div class="wsk-import-options">
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_import_mode" value="merge" checked>
					<span>Add new and update existing</span>
					<span class="wsk-hint">Updates matching names, adds the rest. Safest option.</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_import_mode" value="replace">
					<span>Replace everything</span>
					<span class="wsk-hint">Wipes existing variables of this type and starts fresh.</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_import_mode" value="copy">
					<span>Add as a copy</span>
					<span class="wsk-hint">Always adds new. Duplicates get "-copy" added.</span>
				</label>
			</div>

			<div class="wsk-actions">
				<button id="wsk-import-btn" class="button button-primary">Import Variables</button>
			</div>

			<div id="wsk-import-success" class="wsk-success" style="display:none;"></div>
			<div id="wsk-import-error" class="wsk-error" style="display:none;"></div>
		</div>

		<div class="wsk-card">
			<h2>Tidy up your variables</h2>
			<p class="wsk-description">If your variables are out of order or all mixed up, this puts them back in a clean order. Colors first, then fonts, then sizes.</p>

			<div class="wsk-actions">
				<button id="wsk-reorder-btn" class="button">Reorder Variables</button>
			</div>

			<div id="wsk-reorder-success" class="wsk-success" style="display:none;"></div>
			<div id="wsk-reorder-error" class="wsk-error" style="display:none;"></div>
		</div>
		<?php
	}

	/**
	 * Render the About tab.
	 */
	private function render_about_tab() {
		?>
		<div class="wsk-about__body">
			<img
				src="<?php echo esc_url( WSK_PLUGIN_URL . 'assets/img/rino-profile.jpg' ); ?>"
				alt="Rino de Boer"
				class="wsk-about__photo"
				width="80"
				height="80"
			>

			<p>Hey, my name is Rino. I'm a Dutch web designer and I mainly work with Elementor.</p>

			<p>At some point I started noticing how much time I spent on setup. Not the creative part. The administrative part. Every new project: open a blank site, build the same colors, configure the same spacing, set the same typography. The same decisions, the same clicks, every single time.</p>

			<p>So I built <a href="https://websitestylekit.com" target="_blank" rel="noopener noreferrer">websitestylekit.com</a>. A place where you put together your design system once — your colors, your sizes, your fonts — and keep it ready to go.</p>

			<p>But a design system only means something when it lives inside your tools. That's what this plugin is for. You build your kit on websitestylekit.com, and this plugin gets it into your page builder.</p>

			<p>Right now it works with Elementor, because that's what I use. But websitestylekit.com doesn't belong to any one page builder. Divi, Bricks, whatever comes next — the kit stays the same. The importer just changes.</p>

			<p>I hope it saves you some of that setup time. That's really all it's supposed to do.</p>

			<img
				src="<?php echo esc_url( WSK_PLUGIN_URL . 'assets/img/rino-signature.svg' ); ?>"
				alt="Rino"
				class="wsk-about__signature"
				width="60"
				height="32"
				aria-hidden="true"
			>
		</div>
		<?php
	}

	/**
	 * Render the Changelog tab.
	 */
	private function render_changelog_tab() {
		?>
		<div class="wsk-changelog__body">

			<div class="wsk-changelog__release">
				<div class="wsk-changelog__release-header">
					<span class="wsk-changelog__version">v1.0.0</span>
					<span class="wsk-changelog__date"><?php esc_html_e( 'April 2026', 'websitestylekit' ); ?></span>
				</div>
				<p class="wsk-changelog__intro"><?php esc_html_e( 'First release. Built to connect Elementor V4 design tokens with websitestylekit.com.', 'websitestylekit' ); ?></p>
				<ul class="wsk-changelog__list">
					<li><?php esc_html_e( 'Import colors — paste JSON from websitestylekit.com directly into Elementor V4 global color variables.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Import font sizes — paste CSS clamp values and they are stored as Elementor size variables.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Three import modes: smart merge, replace all, or add as copy.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Export variables — export colors, sizes, and fonts as JSON or raw Elementor format.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Reorder utility — groups variables by type and assigns clean sequential order numbers.', 'websitestylekit' ); ?></li>
				</ul>
			</div>

		</div>
		<?php
	}

	/**
	 * Render the Support tab.
	 */
	private function render_support_tab() {
		?>
		<div class="wsk-support__body">
			<h2><?php esc_html_e( 'Found a bug?', 'websitestylekit' ); ?></h2>
			<p><?php esc_html_e( 'Website Stylekit is a free plugin. There is no official support, but if you run into a bug I would like to know about it so I can fix it.', 'websitestylekit' ); ?></p>
			<p><?php esc_html_e( 'The best place to report it is the WordPress support forum. Just describe what happened and I will take a look when I can.', 'websitestylekit' ); ?></p>
			<a href="https://wordpress.org/support/plugin/websitestylekit/" target="_blank" rel="noopener noreferrer" class="wsk-support__button">
				<?php esc_html_e( 'Go to support forum', 'websitestylekit' ); ?>
			</a>
		</div>
		<?php
	}
}

// Initialize.
Website_Stylekit::get_instance();
