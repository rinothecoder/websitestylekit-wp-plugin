<?php
/**
 * Plugin Name: Website Stylekit
 * Plugin URI: https://rinodeboer.com
 * Description: Import and export Elementor V4 variables and global classes as portable CSS.
 * Version: 2.0
 * Author: Rino de Boer
 * Author URI: https://rinodeboer.com
 * License: GPL v2 or later
 * Text Domain: websitestylekit
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WSK_VERSION', '2.0' );
define( 'WSK_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WSK_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main plugin class.
 */
class Website_Stylekit {

	private static $instance = null;
	const BACKUPS_META_KEY = '_wsk_backups';
	const MAX_BACKUPS = 10;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_ajax_wsk_export_variables', array( $this, 'ajax_export_variables' ) );
		add_action( 'wp_ajax_wsk_import_variables', array( $this, 'ajax_import_variables' ) );
		add_action( 'wp_ajax_wsk_reorder_variables', array( $this, 'ajax_reorder_variables' ) );
		add_action( 'wp_ajax_wsk_create_backup', array( $this, 'ajax_create_backup' ) );
		add_action( 'wp_ajax_wsk_restore_backup', array( $this, 'ajax_restore_backup' ) );
		add_action( 'wp_ajax_wsk_delete_backup', array( $this, 'ajax_delete_backup' ) );
		add_action( 'wp_ajax_wsk_download_backup', array( $this, 'ajax_download_backup' ) );
		add_action( 'wp_ajax_wsk_view_backup', array( $this, 'ajax_view_backup' ) );
		add_action( 'wp_ajax_wsk_upload_backup', array( $this, 'ajax_upload_backup' ) );
	}

	/**
	 * Add menu item under Settings.
	 */
	public function add_admin_menu() {
		$menu_icon_svg = 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 120 120"><path fill="#a7aaad" d="M83 0C103.435 0 120 16.5655 120 37V83C120 103.435 103.435 120 83 120H37C16.5655 120 0 103.435 0 83V37C0 16.5655 16.5655 0 37 0H83ZM101.04 32.9424C96.6498 29.4405 90.2472 27.9148 84.5342 29.002C75.9223 30.6259 70.8418 36.5007 70.8418 44.832C70.8419 52.4289 73.6003 55.7611 84.6182 61.4658C91.2881 64.9254 93.3423 67.1995 93.3564 71.125C93.3705 80.4447 80.8613 84.1305 72.9951 77.127C68.7736 73.3708 67.5633 69.967 59.7676 40.0449C57.7835 32.3915 58.3601 32.9424 52.2676 32.9424C50.0315 32.9424 48.7026 32.7792 47.7598 33.1836L47.3164 33.0615L47.1846 33.5439C45.9052 34.6532 45.3204 37.6377 43.2754 45.5098C41.6853 51.6383 39.5036 59.9697 38.4482 63.9941C37.3796 68.0297 36.5081 71.5014 36.5068 71.7178C36.5068 73.0027 35.6904 71.4354 35.0713 68.9219C30.105 49.0863 26.2499 34.2331 25.9248 33.7188C25.319 32.7728 14.4705 32.8431 14.3291 33.7891C14.2589 34.3264 17.2703 46.2028 24.6719 74.458C27.6124 85.7247 28.1622 87.533 28.7812 88.084C29.7808 88.9594 40.5032 89.0728 41.5586 88.2256C42.1363 87.7423 47.4826 69.0198 50.958 55.3096C51.9571 51.3699 52.267 50.9181 52.6328 52.8525C53.9134 59.7436 58.3042 75.1498 59.8662 78.2705C66.9022 92.3348 87.6442 95.8649 98.6201 84.8506C104.938 78.4962 106.655 68.2587 102.546 61.2266C100.843 58.3318 98.1692 56.1995 91.7246 52.6553C82.8172 47.7553 80.4113 44.5209 82.6768 40.4541C85.0128 36.3029 90.6128 36.3458 95.6504 40.5537C98.2675 42.7423 98.17 42.7845 101.505 38.0684C103.602 35.1313 103.587 34.9615 101.04 32.9424Z"/></svg>' );
		add_menu_page(
			__( 'Website Stylekit', 'websitestylekit' ),
			__( 'Website Stylekit', 'websitestylekit' ),
			'manage_options',
			'website-stylekit',
			array( $this, 'render_admin_page' ),
			$menu_icon_svg
		);
	}

	/**
	 * Enqueue CSS and JS on our admin page only.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( 'toplevel_page_website-stylekit' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'wsk-admin',
			WSK_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			WSK_VERSION
		);

		wp_enqueue_script(
			'wsk-admin',
			WSK_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			WSK_VERSION,
			true
		);

		wp_localize_script( 'wsk-admin', 'wskData', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'wsk_nonce' ),
		) );
	}

	/**
	 * Get the active Elementor kit post ID.
	 */
	private function get_kit_id() {
		$kit_id = get_option( 'elementor_active_kit' );

		if ( ! $kit_id ) {
			return false;
		}

		return (int) $kit_id;
	}

	/**
	 * Read raw variables data from the kit post meta.
	 */
	private function get_raw_variables() {
		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			return new WP_Error( 'no_kit', 'No active Elementor kit found.' );
		}

		$meta = get_post_meta( $kit_id, '_elementor_global_variables', true );

		if ( empty( $meta ) ) {
			return new WP_Error( 'no_variables', 'No variables found. Make sure you have created variables in Elementor.' );
		}

		if ( is_string( $meta ) ) {
			$meta = json_decode( $meta, true );
		}

		if ( ! is_array( $meta ) || ! isset( $meta['data'] ) ) {
			return new WP_Error( 'invalid_data', 'Variable data is in an unexpected format.' );
		}

		return $meta;
	}

	/**
	 * Which variable types to include based on the filter.
	 */
	private function get_type_filter( $filter ) {
		$types = array(
			'colors' => array( 'global-color-variable' ),
			'sizes'  => array( 'global-size-variable', 'global-custom-size-variable' ),
			'fonts'  => array( 'global-font-variable' ),
			'all'    => array( 'global-color-variable', 'global-size-variable', 'global-custom-size-variable', 'global-font-variable' ),
		);

		return $types[ $filter ] ?? $types['all'];
	}

	/**
	 * Convert an Elementor internal type to this plugin's import type.
	 */
	private function get_import_type_from_elementor_type( $elementor_type ) {
		if ( 'global-color-variable' === $elementor_type ) {
			return 'colors';
		}

		if ( in_array( $elementor_type, array( 'global-size-variable', 'global-custom-size-variable' ), true ) ) {
			return 'sizes';
		}

		return false;
	}

	/**
	 * Extract a clean, readable value from Elementor's nested storage format.
	 */
	private function extract_clean_value( $value, $type ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		$inner = $value['value'] ?? $value;

		// Colors: { "$$type": "color", "value": "#hex" }
		if ( 'global-color-variable' === $type ) {
			return is_array( $inner ) ? ( $inner['value'] ?? $inner ) : $inner;
		}

		// Sizes: { "$$type": "size", "value": { "size": 16, "unit": "px" } }
		if ( in_array( $type, array( 'global-size-variable', 'global-custom-size-variable' ), true ) ) {
			if ( is_array( $inner ) && isset( $inner['unit'] ) ) {
				if ( 'custom' === $inner['unit'] ) {
					// Clamp or other custom value.
					return $inner['size'] ?? '';
				}
				if ( 'auto' === $inner['unit'] ) {
					return 'auto';
				}
				return ( $inner['size'] ?? '0' ) . $inner['unit'];
			}
			return $inner;
		}

		// Fonts: { "$$type": "string", "value": "Inter" }
		if ( 'global-font-variable' === $type ) {
			return is_array( $inner ) ? ( $inner['value'] ?? $inner ) : $inner;
		}

		return $inner;
	}

	/**
	 * Export variables as clean JSON.
	 */
	public function export_clean_variables( $filter = 'all' ) {
		$raw = $this->get_raw_variables();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$allowed_types = $this->get_type_filter( $filter );
		$result = array();

		foreach ( $raw['data'] as $id => $variable ) {
			if ( ! empty( $variable['deleted_at'] ) ) {
				continue;
			}

			$type = $variable['type'] ?? '';

			if ( ! in_array( $type, $allowed_types, true ) ) {
				continue;
			}

			$result[ $id ] = array(
				'type'  => $type,
				'label' => $variable['label'] ?? '',
				'value' => $this->extract_clean_value( $variable['value'] ?? '', $type ),
				'order' => $variable['order'] ?? 0,
			);
		}

		uasort( $result, function( $a, $b ) {
			return ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 );
		} );

		return $result;
	}

	/**
	 * Export variables as CSS custom properties.
	 */
	public function export_css_variables( $filter = 'all' ) {
		$variables = $this->export_clean_variables( $filter );

		if ( is_wp_error( $variables ) ) {
			return $variables;
		}

		return $this->build_css_variables_output( $variables );
	}

	/**
	 * Build CSS custom properties from clean variables.
	 */
	private function build_css_variables_output( $variables ) {
		$lines = array( ':root {' );

		foreach ( $variables as $variable ) {
			$type = $variable['type'] ?? '';
			$label = $this->name_to_label( $variable['label'] ?? '' );
			$value = $variable['value'] ?? '';

			if ( '' === $label || is_array( $value ) ) {
				continue;
			}

			if ( 'global-color-variable' === $type ) {
				$name = 'color-' . $label;
			} else {
				$name = $label;
			}

			$lines[] = '  --' . $name . ': ' . $value . ';';
		}

		$lines[] = '}';

		return implode( "\n", $lines );
	}

	/**
	 * Export variables and Elementor's saved global classes as CSS.
	 */
	public function export_css_framework( $filter = 'all' ) {
		$variables = $this->export_clean_variables( $filter );

		if ( is_wp_error( $variables ) ) {
			return $variables;
		}

		$css = $this->build_css_variables_output( $variables );
		$classes_css = $this->export_elementor_global_classes_css();

		if ( '' === $classes_css ) {
			return $css;
		}

		return $css . "\n\n/* Elementor global classes */\n" . $this->format_css_output( $classes_css );
	}

	/**
	 * Remove Elementor's frontend scope from exported class CSS.
	 */
	private function unprefix_elementor_scope( $css ) {
		$css = preg_replace( '/(^|{|})\\s*\\.elementor\\s+/', '$1', $css );
		$css = preg_replace( '/,\\s*\\.elementor\\s+/', ',', $css );

		return $css;
	}

	/**
	 * Make minified CSS readable without changing how browsers or importers parse it.
	 */
	private function format_css_output( $css ) {
		$css = trim( $css );

		if ( '' === $css ) {
			return '';
		}

		$css = preg_replace( '/\\s+/', ' ', $css );
		$output = '';
		$indent = 0;
		$paren_depth = 0;
		$in_selector = true;
		$length = strlen( $css );

		for ( $i = 0; $i < $length; $i++ ) {
			$char = $css[ $i ];

			if ( '(' === $char ) {
				$paren_depth++;
				$output .= $char;
				continue;
			}

			if ( ')' === $char ) {
				$paren_depth = max( 0, $paren_depth - 1 );
				$output .= $char;
				continue;
			}

			if ( ',' === $char && $in_selector && 0 === $paren_depth ) {
				$output = rtrim( $output ) . ",\n" . str_repeat( '  ', $indent );
				continue;
			}

			if ( '{' === $char ) {
				$output = rtrim( $output ) . " {\n";
				$indent++;
				$output .= str_repeat( '  ', $indent );
				$in_selector = false;
				continue;
			}

			if ( ';' === $char ) {
				$output = rtrim( $output ) . ";\n" . str_repeat( '  ', $indent );
				continue;
			}

			if ( '}' === $char ) {
				$indent = max( 0, $indent - 1 );
				$output = rtrim( $output ) . "\n" . str_repeat( '  ', $indent ) . "}\n\n" . str_repeat( '  ', $indent );
				$in_selector = true;
				continue;
			}

			$output .= $char;
		}

		$output = preg_replace( "/\\n{3,}/", "\n\n", $output );

		return trim( $output );
	}

	/**
	 * Export Elementor global classes using Elementor's own atomic styles renderer.
	 */
	private function export_elementor_global_classes_css() {
		$repository_class = '\\Elementor\\Modules\\GlobalClasses\\Global_Classes_Repository';

		if ( ! class_exists( $repository_class ) ) {
			return '';
		}

		$global_classes = $repository_class::make()->all()->get();

		return $this->render_global_classes_css( $global_classes );
	}

	/**
	 * Render a global classes data payload as readable CSS.
	 */
	private function render_global_classes_css( $global_classes ) {
		$renderer_class = '\\Elementor\\Modules\\AtomicWidgets\\Styles\\Styles_Renderer';
		$plugin_class = '\\Elementor\\Plugin';

		if ( ! class_exists( $renderer_class ) || ! class_exists( $plugin_class ) ) {
			return '';
		}

		$items = $global_classes['items'] ?? array();
		$order = $global_classes['order'] ?? array();

		if ( empty( $items ) || empty( $order ) ) {
			return '';
		}

		$ordered_items = array();

		foreach ( $order as $class_id ) {
			if ( empty( $items[ $class_id ] ) || empty( $items[ $class_id ]['label'] ) ) {
				continue;
			}

			$item = $items[ $class_id ];
			$item['id'] = $this->name_to_label( $item['label'] );
			$ordered_items[] = $item;
		}

		if ( empty( $ordered_items ) ) {
			return '';
		}

		$plugin = $plugin_class::$instance ?? null;
		$breakpoints = array();

		if ( $plugin && isset( $plugin->breakpoints ) && method_exists( $plugin->breakpoints, 'get_breakpoints_config' ) ) {
			$breakpoints = $plugin->breakpoints->get_breakpoints_config();
		}

		$css = $renderer_class::make( $breakpoints )->render( array_reverse( $ordered_items ) );

		return $this->unprefix_elementor_scope( $css );
	}

	/**
	 * Export the full raw variable data (mirrors Elementor's storage).
	 */
	public function export_raw_variables( $filter = 'all' ) {
		$raw = $this->get_raw_variables();

		if ( is_wp_error( $raw ) ) {
			return $raw;
		}

		$allowed_types = $this->get_type_filter( $filter );
		$clean_data = array();

		foreach ( $raw['data'] as $id => $variable ) {
			if ( ! empty( $variable['deleted_at'] ) ) {
				continue;
			}

			$type = $variable['type'] ?? '';

			if ( in_array( $type, $allowed_types, true ) ) {
				$clean_data[ $id ] = $variable;
			}
		}

		return array(
			'data'      => $clean_data,
			'watermark' => $raw['watermark'] ?? 0,
			'version'   => $raw['version'] ?? 1,
		);
	}

	/**
	 * AJAX handler for exporting variables.
	 */
	public function ajax_export_variables() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$format = isset( $_POST['format'] ) ? sanitize_text_field( wp_unslash( $_POST['format'] ) ) : 'framework';
		$format = in_array( $format, array( 'framework', 'css', 'clean', 'raw' ), true ) ? $format : 'framework';

		$filter = isset( $_POST['filter'] ) ? sanitize_text_field( wp_unslash( $_POST['filter'] ) ) : 'all';
		$filter = in_array( $filter, array( 'all', 'colors', 'sizes', 'fonts' ), true ) ? $filter : 'all';

		if ( 'framework' === $format ) {
			$result = $this->export_css_framework( $filter );
		} elseif ( 'css' === $format ) {
			$result = $this->export_css_variables( $filter );
		} elseif ( 'raw' === $format ) {
			$result = $this->export_raw_variables( $filter );
		} else {
			$result = $this->export_clean_variables( $filter );
		}

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/**
	 * Generate a random Elementor-style variable ID.
	 */
	private function generate_variable_id() {
		return 'e-gv-' . substr( md5( wp_generate_uuid4() ), 0, 7 );
	}

	/**
	 * Convert a human-readable name to a valid Elementor label.
	 * "Primary Brand 1" becomes "primary-brand-1".
	 */
	private function name_to_label( $name ) {
		$label = strtolower( trim( $name ) );
		$label = preg_replace( '/[^a-z0-9]+/', '-', $label );
		$label = trim( $label, '-' );

		// Max 50 chars.
		if ( strlen( $label ) > 50 ) {
			$label = substr( $label, 0, 50 );
		}

		return $label;
	}

	/**
	 * Detect the Elementor variable type from a CSS custom property name and value.
	 */
	private function detect_css_variable_type( $name, $value ) {
		if ( is_array( $value ) || is_object( $value ) ) {
			return false;
		}

		$name = strtolower( trim( $name ) );
		$value = strtolower( trim( $value ) );

		if ( preg_match( '/^(color|primary|secondary|brand|light|dark)-/', $name ) || preg_match( '/^(#(?:[0-9a-f]{3,8})|rgb\\(|rgba\\(|hsl\\(|hsla\\()/', $value ) ) {
			return 'colors';
		}

		if ( preg_match( '/^(font-family|font)-/', $name ) ) {
			return 'fonts';
		}

		if ( preg_match( '/^(font-size|title-size|body-size|size|space|spacing|radius|gap)-/', $name ) ) {
			return 'sizes';
		}

		if ( preg_match( '/^(clamp|calc|min|max|var)\\s*\\(/', $value ) || preg_match( '/^-?\\d*\\.?\\d+\\s*(px|rem|em|%|vw|vh|vmin|vmax)$/', $value ) || is_numeric( $value ) ) {
			return 'sizes';
		}

		return false;
	}

	/**
	 * Convert a CSS custom property name to a clean Elementor label.
	 */
	private function css_name_to_label( $name, $var_type ) {
		$label = $this->name_to_label( $name );

		if ( 'colors' === $var_type ) {
			$label = preg_replace( '/^color-/', '', $label );
		}

		if ( 'sizes' === $var_type ) {
			$label = preg_replace( '/^font-size-/', '', $label );
		}

		if ( 'fonts' === $var_type ) {
			$label = preg_replace( '/^font-family-/', '', $label );
		}

		return $label;
	}

	/**
	 * Parse CSS custom properties into Elementor-ready variables.
	 * Input: ":root { --color-primary-brand-1: #E9D816; --title-size-1: clamp(...); }"
	 */
	private function parse_css_variables( $css_string ) {
		$variables = array();
		$warnings = array();
		$supported_names = array();

		// Match each --variable-name: value;
		preg_match_all( '/--([a-zA-Z0-9_-]+)\s*:\s*(.+?)\s*;/', $css_string, $matches, PREG_SET_ORDER );

		foreach ( $matches as $index => $m ) {
			$name = trim( $m[1] );
			$value = trim( $m[2] );
			$var_type = $this->detect_css_variable_type( $name, $value );

			if ( ! $var_type ) {
				$warnings[] = 'Skipped unsupported variable --' . $name . '.';
				continue;
			}

			$supported_names[] = strtolower( $name );

			$variables[] = array(
				'id'    => $this->generate_variable_id(),
				'label' => $this->css_name_to_label( $name, $var_type ),
				'value' => $value,
				'order' => $index + 1,
				'type'  => $var_type,
			);
		}

		return array(
			'variables' => $variables,
			'warnings'  => $warnings,
			'names'     => $supported_names,
		);
	}

	/**
	 * Generate a stable Elementor-style global class ID.
	 */
	private function generate_class_id( $existing_ids = array() ) {
		do {
			$id = 'g-' . substr( md5( wp_generate_uuid4() ), 0, 7 );
		} while ( in_array( $id, $existing_ids, true ) );

		return $id;
	}

	/**
	 * Map a rendered media query back to the active Elementor breakpoint ID.
	 */
	private function get_breakpoint_id_from_media_query( $media_query ) {
		$renderer_class = '\\Elementor\\Modules\\AtomicWidgets\\Styles\\Styles_Renderer';
		$plugin_class = '\\Elementor\\Plugin';

		if ( ! class_exists( $renderer_class ) || ! class_exists( $plugin_class ) ) {
			return null;
		}

		$plugin = $plugin_class::$instance ?? null;

		if ( ! $plugin || ! isset( $plugin->breakpoints ) || ! method_exists( $plugin->breakpoints, 'get_breakpoints_config' ) ) {
			return null;
		}

		$normalize = function( $value ) {
			return preg_replace( '/\\s+/', '', strtolower( trim( $value ) ) );
		};

		$needle = $normalize( $media_query );
		$breakpoints = $plugin->breakpoints->get_breakpoints_config();

		foreach ( $breakpoints as $id => $breakpoint ) {
			if ( $needle === $normalize( $renderer_class::get_media_query( $breakpoint ) ?? '' ) ) {
				return $id;
			}
		}

		return null;
	}

	/**
	 * Split a CSS declaration block into a clean raw declaration string.
	 */
	private function clean_declarations( $declarations ) {
		$declarations = trim( $declarations );
		$lines = array();

		foreach ( explode( ';', $declarations ) as $declaration ) {
			$declaration = trim( $declaration );

			if ( '' === $declaration || false === strpos( $declaration, ':' ) || 0 === strpos( $declaration, '--' ) ) {
				continue;
			}

			$lines[] = rtrim( $declaration, ';' ) . ';';
		}

		return implode( "\n", $lines );
	}

	/**
	 * Parse a selector into one or more class/state targets Elementor can store.
	 */
	private function parse_class_selector_targets( $selector ) {
		$targets = array();
		$selector = trim( preg_replace( '/\\s+/', ' ', $selector ) );
		$selector = preg_replace( '/^\\.elementor\\s+/', '', $selector );

		foreach ( explode( ',', $selector ) as $part ) {
			$part = trim( $part );
			$part = preg_replace( '/^\\.elementor\\s+/', '', $part );

			if ( preg_match( '/^\\.([a-zA-Z_-][a-zA-Z0-9_-]*)(?::(hover|active|focus|checked|focus-visible))?$/', $part, $m ) ) {
				$state = $m[2] ?? null;

				if ( 'focus-visible' === $state ) {
					$state = 'hover';
				}

				$targets[] = array(
					'label' => $this->name_to_label( $m[1] ),
					'state' => $state,
				);
			}
		}

		return $targets;
	}

	/**
	 * Parse CSS class rules into Elementor global class variants.
	 */
	private function parse_css_classes( $css_string, $media_query = null ) {
		$classes = array();
		$warnings = array();
		$css_string = preg_replace( '/\\/\\*.*?\\*\\//s', '', $css_string );
		$length = strlen( $css_string );
		$offset = 0;
		$breakpoint = null;

		if ( $media_query ) {
			$breakpoint = $this->get_breakpoint_id_from_media_query( $media_query );

			if ( ! $breakpoint ) {
				return array(
					'classes'  => array(),
					'warnings' => array( 'Skipped rules inside unsupported media query ' . $media_query . '.' ),
				);
			}
		}

		while ( $offset < $length && preg_match( '/([^{}]+)\\{/', $css_string, $match, PREG_OFFSET_CAPTURE, $offset ) ) {
			$selector = trim( $match[1][0] );
			$open_pos = $match[0][1] + strlen( $match[0][0] ) - 1;
			$depth = 1;
			$pos = $open_pos + 1;

			while ( $pos < $length && $depth > 0 ) {
				if ( '{' === $css_string[ $pos ] ) {
					$depth++;
				} elseif ( '}' === $css_string[ $pos ] ) {
					$depth--;
				}
				$pos++;
			}

			if ( 0 !== $depth ) {
				$warnings[] = 'Skipped a CSS rule because its braces did not match.';
				break;
			}

			$body = substr( $css_string, $open_pos + 1, $pos - $open_pos - 2 );
			$offset = $pos;

			if ( 0 === strpos( trim( $selector ), '@media' ) ) {
				if ( preg_match( '/@media\\s*(.+)$/', trim( $selector ), $media_match ) ) {
					$nested = $this->parse_css_classes( $body, trim( $media_match[1] ) );
					foreach ( $nested['classes'] as $label => $class ) {
						if ( ! isset( $classes[ $label ] ) ) {
							$classes[ $label ] = $class;
						} else {
							$classes[ $label ]['variants'] = array_merge( $classes[ $label ]['variants'], $class['variants'] );
						}
					}
					$warnings = array_merge( $warnings, $nested['warnings'] );
				}
				continue;
			}

			if ( ':root' === trim( $selector ) ) {
				continue;
			}

			$targets = $this->parse_class_selector_targets( $selector );
			$declarations = $this->clean_declarations( $body );

			if ( empty( $targets ) || '' === $declarations ) {
				if ( false !== strpos( $selector, '.' ) ) {
					$warnings[] = 'Skipped unsupported selector "' . $selector . '".';
				}
				continue;
			}

			foreach ( $targets as $target ) {
				$label = $target['label'];

				if ( '' === $label ) {
					continue;
				}

				if ( ! isset( $classes[ $label ] ) ) {
					$classes[ $label ] = array(
						'label'    => $label,
						'variants' => array(),
					);
				}

				$classes[ $label ]['variants'][] = array(
					'props'      => array(),
					'custom_css' => array( 'raw' => base64_encode( $declarations ) ),
					'meta'       => array(
						'state'      => $target['state'],
						'breakpoint' => $breakpoint ?? '',
					),
				);
			}
		}

		return array(
			'classes'  => $classes,
			'warnings' => $warnings,
		);
	}

	/**
	 * Detect the format of the pasted input and normalize it into variables/classes.
	 */
	private function parse_import_input( $input ) {
		$input = trim( $input );

		if ( ! preg_match( '/--[a-zA-Z0-9_-]+\\s*:/', $input ) && ! preg_match( '/\\.[a-zA-Z_-][a-zA-Z0-9_-]*\\s*[:,{]/', $input ) ) {
			return new WP_Error( 'invalid_input', 'Paste CSS from Website Stylekit, for example :root { --color-primary: #000; } or .title-1 { font-size: var(--title-size-1); }' );
		}

		$variable_result = $this->parse_css_variables( $input );
		$class_result = $this->parse_css_classes( $input );
		$variables = $variable_result['variables'];
		$classes = $class_result['classes'];
		$warnings = array_merge( $variable_result['warnings'], $class_result['warnings'] );

		if ( empty( $variables ) && empty( $classes ) ) {
			return new WP_Error( 'parse_failed', 'Could not find supported variables or classes. Use tokens like --color-primary: #000; or .title-1 { font-size: var(--title-size-1); }' );
		}

		return array(
			'variables' => $variables,
			'classes'   => $classes,
			'warnings'  => $warnings,
		);
	}

	/**
	 * Parse a size value string into Elementor's storage format.
	 * "1rem" => { "size": 1, "unit": "rem" }
	 * "clamp(...)" => { "size": "clamp(...)", "unit": "custom" }
	 */
	private function parse_size_for_storage( $value ) {
		$value = trim( $value );

		// Clamp, calc, or other function-based values are stored as custom.
		if ( preg_match( '/^(clamp|calc|min|max|var)\s*\(/', $value ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => $value,
					'unit' => 'custom',
				),
			);
		}

		// "auto"
		if ( 'auto' === strtolower( $value ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => '',
					'unit' => 'auto',
				),
			);
		}

		// Simple numeric value with unit: "16px", "2rem", "1.5em", "50%"
		if ( preg_match( '/^(-?\d*\.?\d+)\s*(%|[a-z]+)$/i', $value, $m ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => $m[1] + 0, // Cast to number.
					'unit' => strtolower( $m[2] ),
				),
			);
		}

		// Just a number with no unit, default to px.
		if ( is_numeric( $value ) ) {
			return array(
				'$$type' => 'size',
				'value'  => array(
					'size' => $value + 0,
					'unit' => 'px',
				),
			);
		}

		// Fallback: treat as custom.
		return array(
			'$$type' => 'size',
			'value'  => array(
				'size' => $value,
				'unit' => 'custom',
			),
		);
	}

	/**
	 * Build a lookup of existing active variable labels to their IDs, filtered by type.
	 */
	private function get_existing_label_map( $existing, $elementor_types = array() ) {
		$map = array();

		foreach ( $existing as $id => $var ) {
			if ( isset( $var['deleted_at'] ) ) {
				continue;
			}
			if ( ! empty( $elementor_types ) && ! in_array( $var['type'] ?? '', $elementor_types, true ) ) {
				continue;
			}
			$map[ strtolower( $var['label'] ?? '' ) ] = $id;
		}

		return $map;
	}

	/**
	 * Find the highest order number among ALL active variables (colors, sizes, fonts, etc.).
	 */
	private function get_max_order( $existing ) {
		$max = 0;

		foreach ( $existing as $var ) {
			if ( isset( $var['deleted_at'] ) ) {
				continue;
			}
			$order = $var['order'] ?? 0;
			if ( $order > $max ) {
				$max = $order;
			}
		}

		return $max;
	}

	/**
	 * Build the Elementor V2 storage value for a variable based on its type.
	 */
	private function build_elementor_value( $raw_value, $var_type ) {
		if ( 'sizes' === $var_type ) {
			return $this->parse_size_for_storage( $raw_value );
		}

		if ( 'fonts' === $var_type ) {
			return array(
				'$$type' => 'string',
				'value'  => trim( $raw_value, " \t\n\r\0\x0B\"'" ),
			);
		}

		// Colors.
		return array(
			'$$type' => 'color',
			'value'  => $raw_value,
		);
	}

	/**
	 * Get the Elementor internal type string for a variable type.
	 */
	private function get_elementor_type( $var_type ) {
		$map = array(
			'colors' => 'global-color-variable',
			'sizes'  => 'global-size-variable',
			'fonts'  => 'global-font-variable',
		);

		return $map[ $var_type ] ?? 'global-color-variable';
	}

	/**
	 * Get all Elementor type strings that belong to a variable type (for filtering).
	 */
	private function get_elementor_types_for_filter( $var_type ) {
		$map = array(
			'colors' => array( 'global-color-variable' ),
			'sizes'  => array( 'global-size-variable', 'global-custom-size-variable' ),
			'fonts'  => array( 'global-font-variable' ),
		);

		return $map[ $var_type ] ?? array( 'global-color-variable' );
	}

	/**
	 * Return the import types present in a parsed variable list.
	 */
	private function get_import_types_in_variables( $variables, $fallback_type = 'colors' ) {
		$types = array();

		foreach ( $variables as $variable ) {
			$type = $variable['type'] ?? $fallback_type;
			if ( in_array( $type, array( 'colors', 'sizes', 'fonts' ), true ) ) {
				$types[ $type ] = true;
			}
		}

		return array_keys( $types );
	}

	/**
	 * Convert parsed variables into Elementor V2 storage format and save.
	 *
	 * Modes:
	 * - "merge"   : Add new variables. If a label already exists, update its value.
	 * - "replace" : Delete all existing variables of this type and import fresh.
	 */
	private function import_variables( $variables, $mode = 'merge', $var_type = 'colors' ) {
		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			return new WP_Error( 'no_kit', 'No active Elementor kit found. Make sure Elementor is installed and active.' );
		}

		if ( empty( $variables ) ) {
			return array(
				'imported' => 0,
				'updated'  => 0,
				'total'    => 0,
				'counts'   => array(),
			);
		}

		// Read existing data.
		$meta = get_post_meta( $kit_id, '_elementor_global_variables', true );
		$existing = array();
		$watermark = 0;

		if ( ! empty( $meta ) ) {
			if ( is_string( $meta ) ) {
				$meta = json_decode( $meta, true );
			}
			if ( is_array( $meta ) ) {
				$existing = $meta['data'] ?? array();
				$watermark = $meta['watermark'] ?? 0;
			}
		}

		$now = gmdate( 'Y-m-d H:i:s' );
		$import_types = $this->get_import_types_in_variables( $variables, $var_type );
		$label_maps = array();
		$imported = 0;
		$updated = 0;
		$counts = array();
		$names = array();

		foreach ( $import_types as $import_type ) {
			$label_maps[ $import_type ] = $this->get_existing_label_map( $existing, $this->get_elementor_types_for_filter( $import_type ) );
			$counts[ $import_type ] = array(
				'imported' => 0,
				'updated'  => 0,
			);
			$names[ $import_type ] = array(
				'imported' => array(),
				'updated'  => array(),
			);
		}

		if ( 'replace' === $mode ) {
			// Soft-delete all existing variables of the imported types.
			foreach ( $existing as $id => &$var ) {
				foreach ( $import_types as $import_type ) {
					if ( isset( $var['type'] ) && in_array( $var['type'], $this->get_elementor_types_for_filter( $import_type ), true ) && ! isset( $var['deleted_at'] ) ) {
						$var['deleted_at'] = $now;
						break;
					}
				}
			}
			unset( $var );

			foreach ( $import_types as $import_type ) {
				$label_maps[ $import_type ] = array();
			}
		}

		// Determine starting order for new variables.
		$next_order = ( 'replace' === $mode ) ? 1 : $this->get_max_order( $existing ) + 1;

		foreach ( $variables as $variable ) {
			$current_type = $variable['type'] ?? $var_type;

			if ( ! in_array( $current_type, array( 'colors', 'sizes', 'fonts' ), true ) ) {
				continue;
			}

			$label = $variable['label'];
			$elementor_type = $this->get_elementor_type( $current_type );
			$label_map = $label_maps[ $current_type ] ?? array();
			$existing_id = $label_map[ strtolower( $label ) ] ?? null;
			$storage_value = $this->build_elementor_value( $variable['value'], $current_type );

			if ( 'merge' === $mode && $existing_id ) {
				// Update the existing variable's value.
				$existing[ $existing_id ]['value'] = $storage_value;
				$existing[ $existing_id ]['updated_at'] = $now;
				$updated++;
				$counts[ $current_type ]['updated']++;
				$names[ $current_type ]['updated'][] = $label;

			} else {
				// New variable (all modes).
				$new_id = $variable['id'] ?? $this->generate_variable_id();
				$order = ( 'replace' === $mode ) ? $variable['order'] : $next_order++;

				$existing[ $new_id ] = array(
					'type'       => $elementor_type,
					'label'      => $label,
					'value'      => $storage_value,
					'order'      => $order,
					'created_at' => $now,
					'updated_at' => $now,
				);

				$label_maps[ $current_type ][ strtolower( $label ) ] = $new_id;
				$imported++;
				$counts[ $current_type ]['imported']++;
				$names[ $current_type ]['imported'][] = $label;
			}
		}

		$watermark++;

		$record = array(
			'data'      => $existing,
			'watermark' => $watermark,
			'version'   => 2,
		);

		$result = update_post_meta(
			$kit_id,
			'_elementor_global_variables',
			wp_slash( wp_json_encode( $record ) )
		);

		if ( false === $result ) {
			return new WP_Error( 'save_failed', 'Failed to save variables to the database.' );
		}

		return array(
			'imported' => $imported,
			'updated'  => $updated,
			'total'    => $imported + $updated,
			'counts'   => $counts,
			'names'    => $names,
		);
	}

	/**
	 * Read Elementor global classes from the active kit.
	 */
	private function get_existing_global_classes() {
		$repository_class = '\\Elementor\\Modules\\GlobalClasses\\Global_Classes_Repository';

		if ( ! class_exists( $repository_class ) ) {
			return new WP_Error( 'classes_unavailable', 'Elementor global classes are not available on this site.' );
		}

		try {
			$data = $repository_class::make()->all()->get();
		} catch ( Exception $e ) {
			return new WP_Error( 'classes_read_failed', 'Could not read Elementor global classes.' );
		}

		return array(
			'items' => $data['items'] ?? array(),
			'order' => $data['order'] ?? array(),
		);
	}

	/**
	 * Build a lookup of existing class labels to class IDs.
	 */
	private function get_existing_class_label_map( $items ) {
		$map = array();

		foreach ( $items as $id => $item ) {
			if ( empty( $item['label'] ) ) {
				continue;
			}

			$map[ strtolower( $this->name_to_label( $item['label'] ) ) ] = $id;
		}

		return $map;
	}

	/**
	 * Create an Elementor global class item from parsed CSS.
	 */
	private function build_class_item( $class_id, $class_data ) {
		return array(
			'id'       => $class_id,
			'type'     => 'class',
			'label'    => $class_data['label'],
			'cssName'  => $class_data['label'],
			'variants' => $class_data['variants'],
		);
	}

	/**
	 * Save parsed CSS classes into Elementor global classes.
	 */
	private function import_classes( $classes, $mode = 'merge' ) {
		if ( empty( $classes ) ) {
			return array(
				'imported' => 0,
				'updated'  => 0,
				'total'    => 0,
			);
		}

		$repository_class = '\\Elementor\\Modules\\GlobalClasses\\Global_Classes_Repository';
		$parser_class = '\\Elementor\\Modules\\GlobalClasses\\Global_Classes_Parser';

		if ( ! class_exists( $repository_class ) || ! class_exists( $parser_class ) ) {
			return new WP_Error( 'classes_unavailable', 'Elementor global classes are not available on this site.' );
		}

		$existing = $this->get_existing_global_classes();

		if ( is_wp_error( $existing ) ) {
			return $existing;
		}

		$items = ( 'replace' === $mode ) ? array() : ( $existing['items'] ?? array() );
		$order = ( 'replace' === $mode ) ? array() : ( $existing['order'] ?? array() );
		$label_map = ( 'replace' === $mode ) ? array() : $this->get_existing_class_label_map( $items );
		$imported = 0;
		$updated = 0;
		$names = array(
			'imported' => array(),
			'updated'  => array(),
		);

		foreach ( $classes as $class ) {
			$label = $class['label'];
			$existing_id = $label_map[ strtolower( $label ) ] ?? null;

			if ( $existing_id ) {
				$items[ $existing_id ] = $this->build_class_item( $existing_id, $class );
				$updated++;
				$names['updated'][] = $label;
				continue;
			}

			$new_id = $this->generate_class_id( array_keys( $items ) );
			$items[ $new_id ] = $this->build_class_item( $new_id, $class );
			$order[] = $new_id;
			$label_map[ strtolower( $label ) ] = $new_id;
			$imported++;
			$names['imported'][] = $label;
		}

		$parsed = $parser_class::make()->parse(
			array(
				'items' => $items,
				'order' => $order,
			)
		);

		if ( ! $parsed->is_valid() ) {
			return new WP_Error( 'classes_invalid', 'Elementor rejected one or more imported classes. Check for unsupported class names or CSS.' );
		}

		$validated = $parsed->unwrap();

		try {
			$repository_class::make()->put( $validated['items'], $validated['order'] );
		} catch ( Exception $e ) {
			return new WP_Error( 'classes_save_failed', 'Failed to save Elementor global classes.' );
		}

		return array(
			'imported' => $imported,
			'updated'  => $updated,
			'total'    => $imported + $updated,
			'names'    => $names,
		);
	}

	/**
	 * Read Website Stylekit backups from the active Elementor kit.
	 */
	private function get_backups() {
		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			return array();
		}

		$backups = get_post_meta( $kit_id, self::BACKUPS_META_KEY, true );

		if ( is_string( $backups ) ) {
			$backups = json_decode( $backups, true );
		}

		return is_array( $backups ) ? $backups : array();
	}

	/**
	 * Save Website Stylekit backups on the active Elementor kit.
	 */
	private function save_backups( $backups ) {
		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			return new WP_Error( 'no_kit', 'No active Elementor kit found.' );
		}

		return update_post_meta( $kit_id, self::BACKUPS_META_KEY, wp_slash( wp_json_encode( array_values( $backups ) ) ) );
	}

	/**
	 * Count active variables in a stored Elementor variables payload.
	 */
	private function count_backup_variables( $variables ) {
		$data = $variables['data'] ?? array();
		$count = 0;

		foreach ( $data as $variable ) {
			if ( empty( $variable['deleted_at'] ) ) {
				$count++;
			}
		}

		return $count;
	}

	/**
	 * Count global classes in a stored Elementor classes payload.
	 */
	private function count_backup_classes( $classes ) {
		return count( $classes['items'] ?? array() );
	}

	/**
	 * Create a snapshot of current Elementor variables and global classes.
	 */
	private function create_backup( $label = 'Manual backup', $mode = 'manual' ) {
		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			return new WP_Error( 'no_kit', 'No active Elementor kit found.' );
		}

		$variables = get_post_meta( $kit_id, '_elementor_global_variables', true );

		if ( is_string( $variables ) ) {
			$variables = json_decode( $variables, true );
		}

		if ( ! is_array( $variables ) ) {
			$variables = array(
				'data'      => array(),
				'watermark' => 0,
				'version'   => 2,
			);
		}

		$classes = $this->get_existing_global_classes();

		if ( is_wp_error( $classes ) ) {
			$classes = array(
				'items' => array(),
				'order' => array(),
			);
		}

		$backup = array(
			'id'             => 'wsk-' . substr( md5( wp_generate_uuid4() ), 0, 12 ),
			'created_at'     => current_time( 'mysql' ),
			'timestamp'      => time(),
			'label'          => sanitize_text_field( $label ),
			'mode'           => sanitize_text_field( $mode ),
			'variables'      => $variables,
			'classes'        => $classes,
			'variable_count' => $this->count_backup_variables( $variables ),
			'class_count'    => $this->count_backup_classes( $classes ),
		);

		$backups = $this->get_backups();
		array_unshift( $backups, $backup );
		$backups = array_slice( $backups, 0, self::MAX_BACKUPS );

		$saved = $this->save_backups( $backups );

		if ( false === $saved ) {
			return new WP_Error( 'backup_failed', 'Failed to save backup.' );
		}

		return $backup;
	}

	/**
	 * Add an uploaded backup file to the active kit's backup list.
	 */
	private function import_uploaded_backup( $backup ) {
		if ( ! is_array( $backup ) ) {
			return new WP_Error( 'invalid_backup', 'This backup file could not be read.' );
		}

		if ( empty( $backup['variables'] ) || ! is_array( $backup['variables'] ) || empty( $backup['classes'] ) || ! is_array( $backup['classes'] ) ) {
			return new WP_Error( 'invalid_backup', 'This does not look like a Website Stylekit backup file.' );
		}

		$imported = array(
			'id'             => 'wsk-' . substr( md5( wp_generate_uuid4() ), 0, 12 ),
			'created_at'     => current_time( 'mysql' ),
			'timestamp'      => time(),
			'label'          => sanitize_text_field( $backup['label'] ?? 'Uploaded backup' ),
			'mode'           => 'uploaded backup',
			'variables'      => $backup['variables'],
			'classes'        => $backup['classes'],
			'variable_count' => $this->count_backup_variables( $backup['variables'] ),
			'class_count'    => $this->count_backup_classes( $backup['classes'] ),
		);

		$backups = $this->get_backups();
		array_unshift( $backups, $imported );
		$backups = array_slice( $backups, 0, self::MAX_BACKUPS );

		$saved = $this->save_backups( $backups );

		if ( false === $saved ) {
			return new WP_Error( 'backup_failed', 'Failed to save uploaded backup.' );
		}

		return $imported;
	}

	/**
	 * Find one stored backup by ID.
	 */
	private function find_backup( $backup_id ) {
		foreach ( $this->get_backups() as $backup ) {
			if ( isset( $backup['id'] ) && $backup_id === $backup['id'] ) {
				return $backup;
			}
		}

		return false;
	}

	/**
	 * Restore variables and classes from a backup.
	 */
	private function restore_backup( $backup_id ) {
		$kit_id = $this->get_kit_id();
		$backup = $this->find_backup( $backup_id );

		if ( ! $kit_id ) {
			return new WP_Error( 'no_kit', 'No active Elementor kit found.' );
		}

		if ( ! $backup ) {
			return new WP_Error( 'missing_backup', 'Backup not found.' );
		}

		$variables = $backup['variables'] ?? array(
			'data'      => array(),
			'watermark' => 0,
			'version'   => 2,
		);

		update_post_meta( $kit_id, '_elementor_global_variables', wp_slash( wp_json_encode( $variables ) ) );

		$repository_class = '\\Elementor\\Modules\\GlobalClasses\\Global_Classes_Repository';
		$classes = $backup['classes'] ?? array();

		if ( class_exists( $repository_class ) && is_array( $classes ) ) {
			try {
				$repository_class::make()->put( $classes['items'] ?? array(), $classes['order'] ?? array() );
			} catch ( Exception $e ) {
				return new WP_Error( 'classes_restore_failed', 'Variables were restored, but Elementor classes could not be restored.' );
			}
		}

		return $backup;
	}

	/**
	 * Delete a stored backup.
	 */
	private function delete_backup( $backup_id ) {
		$backups = $this->get_backups();
		$filtered = array_values( array_filter( $backups, function( $backup ) use ( $backup_id ) {
			return ( $backup['id'] ?? '' ) !== $backup_id;
		} ) );

		if ( count( $filtered ) === count( $backups ) ) {
			return new WP_Error( 'missing_backup', 'Backup not found.' );
		}

		$saved = $this->save_backups( $filtered );

		if ( false === $saved ) {
			return new WP_Error( 'delete_failed', 'Failed to delete backup.' );
		}

		return true;
	}

	/**
	 * Convert a backup snapshot into readable CSS for preview.
	 */
	private function build_backup_css_preview( $backup ) {
		$clean_variables = array();
		$variables = $backup['variables']['data'] ?? array();

		foreach ( $variables as $id => $variable ) {
			if ( ! empty( $variable['deleted_at'] ) ) {
				continue;
			}

			$type = $variable['type'] ?? '';

			$clean_variables[ $id ] = array(
				'type'  => $type,
				'label' => $variable['label'] ?? '',
				'value' => $this->extract_clean_value( $variable['value'] ?? '', $type ),
				'order' => $variable['order'] ?? 0,
			);
		}

		uasort( $clean_variables, function( $a, $b ) {
			return ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 );
		} );

		$css_parts = array();

		if ( ! empty( $clean_variables ) ) {
			$css_parts[] = '/* Variables */' . "\n" . $this->build_css_variables_output( $clean_variables );
		}

		$classes_css = $this->render_global_classes_css( $backup['classes'] ?? array() );

		if ( '' !== $classes_css ) {
			$css_parts[] = '/* Elementor global classes */' . "\n" . $this->format_css_output( $classes_css );
		}

		return implode( "\n\n", $css_parts );
	}

	/**
	 * Create a preview summary without changing Elementor.
	 */
	private function preview_import( $parsed, $mode = 'merge' ) {
		$variables = $parsed['variables'] ?? array();
		$classes = $parsed['classes'] ?? array();
		$warnings = $parsed['warnings'] ?? array();
		$counts = array(
			'colors'  => array( 'imported' => 0, 'updated' => 0 ),
			'fonts'   => array( 'imported' => 0, 'updated' => 0 ),
			'sizes'   => array( 'imported' => 0, 'updated' => 0 ),
			'classes' => array( 'imported' => 0, 'updated' => 0 ),
		);
		$names = array(
			'colors'  => array( 'imported' => array(), 'updated' => array() ),
			'fonts'   => array( 'imported' => array(), 'updated' => array() ),
			'sizes'   => array( 'imported' => array(), 'updated' => array() ),
			'classes' => array( 'imported' => array(), 'updated' => array() ),
		);

		$kit_id = $this->get_kit_id();
		$existing_variables = array();

		if ( $kit_id ) {
			$meta = get_post_meta( $kit_id, '_elementor_global_variables', true );

			if ( is_string( $meta ) ) {
				$meta = json_decode( $meta, true );
			}

			if ( is_array( $meta ) ) {
				$existing_variables = $meta['data'] ?? array();
			}
		}

		$variable_maps = array();
		foreach ( $this->get_import_types_in_variables( $variables ) as $type ) {
			$variable_maps[ $type ] = ( 'replace' === $mode ) ? array() : $this->get_existing_label_map( $existing_variables, $this->get_elementor_types_for_filter( $type ) );
		}

		foreach ( $variables as $variable ) {
			$type = $variable['type'] ?? 'colors';
			$label = $variable['label'] ?? '';
			$label_key = strtolower( $label );

			if ( 'merge' === $mode && isset( $variable_maps[ $type ][ $label_key ] ) ) {
				$counts[ $type ]['updated']++;
				$names[ $type ]['updated'][] = $label;
			} else {
				$counts[ $type ]['imported']++;
				$names[ $type ]['imported'][] = $label;
			}
		}

		$existing_classes = $this->get_existing_global_classes();

		if ( is_wp_error( $existing_classes ) ) {
			if ( ! empty( $classes ) ) {
				$warnings[] = $existing_classes->get_error_message();
			}
			$class_map = array();
		} else {
			$class_map = ( 'replace' === $mode ) ? array() : $this->get_existing_class_label_map( $existing_classes['items'] ?? array() );
		}

		foreach ( $classes as $class ) {
			$label = $class['label'] ?? '';
			$label_key = strtolower( $label );

			if ( 'merge' === $mode && isset( $class_map[ $label_key ] ) ) {
				$counts['classes']['updated']++;
				$names['classes']['updated'][] = $label;
			} else {
				$counts['classes']['imported']++;
				$names['classes']['imported'][] = $label;
			}
		}

		if ( 'replace' === $mode && ! empty( $classes ) ) {
			$warnings[] = 'Replace mode will clear existing Elementor global classes before importing these classes.';
		}

		return array(
			'imported' => $counts['colors']['imported'] + $counts['fonts']['imported'] + $counts['sizes']['imported'] + $counts['classes']['imported'],
			'updated'  => $counts['colors']['updated'] + $counts['fonts']['updated'] + $counts['sizes']['updated'] + $counts['classes']['updated'],
			'total'    => array_sum( array_map( function( $count ) {
				return $count['imported'] + $count['updated'];
			}, $counts ) ),
			'counts'   => $counts,
			'names'    => $names,
			'warnings' => array_values( array_unique( $warnings ) ),
		);
	}

	/**
	 * AJAX handler for importing variables.
	 */
	public function ajax_import_variables() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$json_input = isset( $_POST['json_input'] ) ? sanitize_textarea_field( wp_unslash( $_POST['json_input'] ) ) : '';
		$mode = isset( $_POST['mode'] ) ? sanitize_text_field( wp_unslash( $_POST['mode'] ) ) : 'merge';
		$mode = in_array( $mode, array( 'merge', 'replace' ), true ) ? $mode : 'merge';

		if ( empty( $json_input ) ) {
			wp_send_json_error( 'No input provided.' );
		}

		$dry_run = ! empty( $_POST['dry_run'] );
		$parsed = $this->parse_import_input( $json_input );

		if ( is_wp_error( $parsed ) ) {
			wp_send_json_error( $parsed->get_error_message() );
		}

		if ( $dry_run ) {
			wp_send_json_success( $this->preview_import( $parsed, $mode ) );
		}

		$backup = $this->create_backup( 'Before stylekit import', $mode . ' import' );

		if ( is_wp_error( $backup ) ) {
			wp_send_json_error( $backup->get_error_message() );
		}

		$variable_result = $this->import_variables( $parsed['variables'], $mode );

		if ( is_wp_error( $variable_result ) ) {
			wp_send_json_error( $variable_result->get_error_message() );
		}

		$class_result = $this->import_classes( $parsed['classes'], $mode );

		if ( is_wp_error( $class_result ) ) {
			wp_send_json_error( $class_result->get_error_message() );
		}

		$result = $this->preview_import( $parsed, $mode );
		$result['counts']['colors'] = $variable_result['counts']['colors'] ?? array( 'imported' => 0, 'updated' => 0 );
		$result['counts']['fonts'] = $variable_result['counts']['fonts'] ?? array( 'imported' => 0, 'updated' => 0 );
		$result['counts']['sizes'] = $variable_result['counts']['sizes'] ?? array( 'imported' => 0, 'updated' => 0 );
		$result['counts']['classes'] = array(
			'imported' => $class_result['imported'] ?? 0,
			'updated'  => $class_result['updated'] ?? 0,
		);
		$result['names']['colors'] = $variable_result['names']['colors'] ?? array( 'imported' => array(), 'updated' => array() );
		$result['names']['fonts'] = $variable_result['names']['fonts'] ?? array( 'imported' => array(), 'updated' => array() );
		$result['names']['sizes'] = $variable_result['names']['sizes'] ?? array( 'imported' => array(), 'updated' => array() );
		$result['names']['classes'] = $class_result['names'] ?? array( 'imported' => array(), 'updated' => array() );
		$result['imported'] = ( $variable_result['imported'] ?? 0 ) + ( $class_result['imported'] ?? 0 );
		$result['updated'] = ( $variable_result['updated'] ?? 0 ) + ( $class_result['updated'] ?? 0 );
		$result['total'] = $result['imported'] + $result['updated'];
		$result['backup'] = array(
			'id'    => $backup['id'],
			'label' => $backup['label'],
		);

		wp_send_json_success( $result );
	}

	/**
	 * AJAX handler for creating a manual backup.
	 */
	public function ajax_create_backup() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$backup = $this->create_backup( 'Manual backup', 'manual' );

		if ( is_wp_error( $backup ) ) {
			wp_send_json_error( $backup->get_error_message() );
		}

		wp_send_json_success( array(
			'id' => $backup['id'],
		) );
	}

	/**
	 * AJAX handler for restoring a backup.
	 */
	public function ajax_restore_backup() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$backup_id = isset( $_POST['backup_id'] ) ? sanitize_text_field( wp_unslash( $_POST['backup_id'] ) ) : '';
		$result = $this->restore_backup( $backup_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( array(
			'id' => $backup_id,
		) );
	}

	/**
	 * AJAX handler for deleting a backup.
	 */
	public function ajax_delete_backup() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$backup_id = isset( $_POST['backup_id'] ) ? sanitize_text_field( wp_unslash( $_POST['backup_id'] ) ) : '';
		$result = $this->delete_backup( $backup_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( array(
			'id' => $backup_id,
		) );
	}

	/**
	 * AJAX handler for downloading a backup as JSON.
	 */
	public function ajax_download_backup() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$backup_id = isset( $_POST['backup_id'] ) ? sanitize_text_field( wp_unslash( $_POST['backup_id'] ) ) : '';
		$backup = $this->find_backup( $backup_id );

		if ( ! $backup ) {
			wp_send_json_error( 'Backup not found.' );
		}

		wp_send_json_success( $backup );
	}

	/**
	 * AJAX handler for viewing a backup as readable CSS.
	 */
	public function ajax_view_backup() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$backup_id = isset( $_POST['backup_id'] ) ? sanitize_text_field( wp_unslash( $_POST['backup_id'] ) ) : '';
		$backup = $this->find_backup( $backup_id );

		if ( ! $backup ) {
			wp_send_json_error( 'Backup not found.' );
		}

		wp_send_json_success( array(
			'id'             => $backup['id'] ?? '',
			'label'          => $backup['label'] ?? 'Backup',
			'created_at'     => $backup['created_at'] ?? '',
			'mode'           => $backup['mode'] ?? '',
			'variable_count' => (int) ( $backup['variable_count'] ?? 0 ),
			'class_count'    => (int) ( $backup['class_count'] ?? 0 ),
			'css'            => $this->build_backup_css_preview( $backup ),
		) );
	}

	/**
	 * AJAX handler for uploading a backup JSON file.
	 */
	public function ajax_upload_backup() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$backup_json = isset( $_POST['backup_json'] ) ? wp_unslash( $_POST['backup_json'] ) : '';

		if ( '' === trim( $backup_json ) ) {
			wp_send_json_error( 'No backup file data found.' );
		}

		if ( strlen( $backup_json ) > 2 * 1024 * 1024 ) {
			wp_send_json_error( 'This backup file is too large.' );
		}

		$backup = json_decode( $backup_json, true );

		if ( ! is_array( $backup ) ) {
			wp_send_json_error( 'This backup file is not valid JSON.' );
		}

		$result = $this->import_uploaded_backup( $backup );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( array(
			'id' => $result['id'],
		) );
	}

	/**
	 * Reorder all active variables: group by type, then assign sequential order numbers.
	 * Order: colors first, then fonts, then sizes.
	 */
	public function ajax_reorder_variables() {
		check_ajax_referer( 'wsk_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized.' );
		}

		$kit_id = $this->get_kit_id();

		if ( ! $kit_id ) {
			wp_send_json_error( 'No active Elementor kit found.' );
		}

		$meta = get_post_meta( $kit_id, '_elementor_global_variables', true );

		if ( empty( $meta ) ) {
			wp_send_json_error( 'No variables found.' );
		}

		if ( is_string( $meta ) ) {
			$meta = json_decode( $meta, true );
		}

		if ( ! is_array( $meta ) || ! isset( $meta['data'] ) ) {
			wp_send_json_error( 'Variable data is in an unexpected format.' );
		}

		$existing = $meta['data'];
		$watermark = $meta['watermark'] ?? 0;

		// Group active variables by type.
		$type_order = array(
			'global-color-variable'       => 1,
			'global-font-variable'        => 2,
			'global-size-variable'        => 3,
			'global-custom-size-variable' => 3,
		);

		$active = array();
		foreach ( $existing as $id => $var ) {
			if ( isset( $var['deleted_at'] ) ) {
				continue;
			}
			$active[ $id ] = $var;
		}

		// Sort by type group first, then by current order within the group.
		uasort( $active, function( $a, $b ) use ( $type_order ) {
			$type_a = $type_order[ $a['type'] ?? '' ] ?? 99;
			$type_b = $type_order[ $b['type'] ?? '' ] ?? 99;

			if ( $type_a !== $type_b ) {
				return $type_a - $type_b;
			}

			return ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 );
		} );

		// Assign fresh sequential order numbers.
		$order = 1;
		$now = gmdate( 'Y-m-d H:i:s' );

		foreach ( $active as $id => $var ) {
			$existing[ $id ]['order'] = $order++;
			$existing[ $id ]['updated_at'] = $now;
		}

		$watermark++;

		$record = array(
			'data'      => $existing,
			'watermark' => $watermark,
			'version'   => 2,
		);

		$result = update_post_meta(
			$kit_id,
			'_elementor_global_variables',
			wp_slash( wp_json_encode( $record ) )
		);

		if ( false === $result ) {
			wp_send_json_error( 'Failed to save.' );
		}

		// Count by type for the summary.
		$counts = array();
		foreach ( $active as $var ) {
			$type = $var['type'] ?? 'unknown';
			$counts[ $type ] = ( $counts[ $type ] ?? 0 ) + 1;
		}

		wp_send_json_success( array(
			'total'  => count( $active ),
			'counts' => $counts,
		) );
	}

	/**
	 * Render the admin page.
	 */
	public function render_admin_page() {
		?>
		<div class="wsk-wrap">

			<header class="wsk-header">
				<div class="wsk-header-inner">
					<div class="wsk-header__left">
						<img
							src="<?php echo esc_url( WSK_PLUGIN_URL . 'assets/img/wsk-icon.svg' ); ?>"
							alt="Website Stylekit"
							class="wsk-header__icon"
							width="28"
							height="28"
						>
						<h1 class="wsk-header__title">Website Stylekit</h1>
						<span class="wsk-header__version">v<?php echo esc_html( WSK_VERSION ); ?></span>
					</div>
					<nav class="wsk-header__nav">
						<a href="#import" class="wsk-header__link wsk-header__link--active" data-tab="import">Import</a>
						<a href="#export" class="wsk-header__link" data-tab="export">Export</a>
						<a href="#backups" class="wsk-header__link" data-tab="backups">Backups</a>
						<a href="#about" class="wsk-header__link" data-tab="about">About</a>
						<a href="#changelog" class="wsk-header__link" data-tab="changelog">Changelog</a>
						<?php /* Support tab hidden for now — content preserved, enable by uncommenting the line below */ ?>
						<?php // echo '<a href="#support" class="wsk-header__link" data-tab="support">Support</a>'; ?>
					</nav>
				</div>
			</header>

			<div class="wsk-content">
				<div class="wsk-tab-panel active" data-tab="import">
					<?php $this->render_import_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="export">
					<?php $this->render_export_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="backups">
					<?php $this->render_backups_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="about">
					<?php $this->render_about_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="changelog">
					<?php $this->render_changelog_tab(); ?>
				</div>
				<div class="wsk-tab-panel" data-tab="support">
					<?php $this->render_support_tab(); ?>
				</div>
			</div>

		</div>
		<?php
	}

	/**
	 * Render the Export tab.
	 */
	private function render_export_tab() {
		?>
		<div class="wsk-card">
			<h2>Export your stylekit</h2>
			<p class="wsk-description">Export your Elementor variables and global classes as portable CSS.</p>
			<input type="hidden" name="wsk_filter" value="all">

			<h3 class="wsk-section-label">Output format</h3>
			<div class="wsk-format-toggle">
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_format" value="framework" checked>
					<span>CSS Framework</span>
					<span class="wsk-hint">Variables &amp; Classes</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_format" value="css">
					<span>CSS Variables</span>
					<span class="wsk-hint">Variables only</span>
				</label>
			</div>

			<details id="wsk-advanced-export" class="wsk-advanced-export">
				<summary>Advanced JSON exports</summary>
				<div class="wsk-format-toggle">
					<label class="wsk-radio-label">
						<input type="radio" name="wsk_format" value="clean">
						<span>Clean JSON</span>
						<span class="wsk-hint">Simple label, value and order data</span>
					</label>
					<label class="wsk-radio-label">
						<input type="radio" name="wsk_format" value="raw">
						<span>Raw Elementor JSON</span>
						<span class="wsk-hint">Elementor's original stored format</span>
					</label>
				</div>
			</details>

			<div id="wsk-export-scope" class="wsk-export-scope">
				<h3 class="wsk-section-label">Variable type</h3>
				<div class="wsk-format-toggle">
					<label class="wsk-radio-label">
						<input type="radio" name="wsk_filter_advanced" value="all" checked>
						<span>All variables</span>
					</label>
					<label class="wsk-radio-label">
						<input type="radio" name="wsk_filter_advanced" value="colors">
						<span>Colors only</span>
					</label>
					<label class="wsk-radio-label">
						<input type="radio" name="wsk_filter_advanced" value="sizes">
						<span>Sizes only</span>
					</label>
					<label class="wsk-radio-label">
						<input type="radio" name="wsk_filter_advanced" value="fonts">
						<span>Fonts only</span>
					</label>
				</div>
			</div>

			<div class="wsk-actions">
				<button id="wsk-export-btn" class="button button-primary">Export</button>
				<button id="wsk-copy-btn" class="button" style="display:none;">Copy to Clipboard</button>
				<button id="wsk-download-btn" class="button" style="display:none;">Download CSS</button>
			</div>

			<div id="wsk-export-result" style="display:none;">
				<h3>Result</h3>
				<textarea id="wsk-export-output" readonly rows="20"></textarea>
			</div>

			<div id="wsk-export-error" class="wsk-error" style="display:none;"></div>
		</div>
		<?php
	}

	/**
	 * Render the Import tab.
	 */
	private function render_import_tab() {
		?>
		<div class="wsk-card">
			<h2>Import your stylekit</h2>
			<p class="wsk-description">Paste your Website Stylekit CSS below. Right now this importer writes to Elementor V4 variables and Atomic Editor global classes.</p>

			<textarea id="wsk-import-input" rows="16" placeholder=':root {
  --font-family-heading: "Roboto";
  --font-family-body: "Roboto";
  --color-primary-brand-1: #E9D816;
  --title-size-1: clamp(3rem, 1.7566rem + 5.5263vw, 5.625rem);
  --size-32: clamp(1.5rem, 1.2632rem + 1.0526vw, 2rem);
}

.title-1 {
  font-size: var(--title-size-1);
  color: var(--color-dark-1);
}'></textarea>

			<h3 class="wsk-section-label">Import target</h3>
			<div class="wsk-format-toggle">
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_import_target" value="elementor" checked>
					<span>Elementor</span>
					<span class="wsk-hint">V4 Atomic Editor: variables and classes</span>
				</label>
				<label class="wsk-radio-label wsk-radio-label--disabled">
					<input type="radio" name="wsk_import_target" value="bricks" disabled>
					<span>Bricks</span>
					<span class="wsk-hint">Coming soon</span>
				</label>
			</div>

			<h3 class="wsk-section-label">How should we handle existing styles?</h3>
			<div class="wsk-import-options">
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_import_mode" value="merge" checked>
					<span>Add new and update existing</span>
					<span class="wsk-hint">Updates matching names and adds the rest. Safest option.</span>
				</label>
				<label class="wsk-radio-label">
					<input type="radio" name="wsk_import_mode" value="replace">
					<span>Replace everything</span>
					<span class="wsk-hint">Clears the imported style types first, then adds the new CSS.</span>
				</label>
			</div>

			<div id="wsk-import-preview" class="wsk-import-preview" style="display:none;"></div>

			<div class="wsk-actions">
				<button id="wsk-preview-import-btn" class="button">Preview Import</button>
				<button id="wsk-import-btn" class="button button-primary" style="display:none;">Apply Import</button>
			</div>

			<div id="wsk-import-success" class="wsk-success" style="display:none;"></div>
			<div id="wsk-import-error" class="wsk-error" style="display:none;"></div>
		</div>

		<div class="wsk-card">
			<h2>Tidy up your variables</h2>
			<p class="wsk-description">If your variables are out of order or all mixed up, this puts them back in a clean order. Colors first, then fonts, then sizes.</p>

			<div class="wsk-actions">
				<button id="wsk-reorder-btn" class="button">Reorder Variables</button>
			</div>

			<div id="wsk-reorder-success" class="wsk-success" style="display:none;"></div>
			<div id="wsk-reorder-error" class="wsk-error" style="display:none;"></div>
		</div>
		<?php
	}

	/**
	 * Render the Backups tab.
	 */
	private function render_backups_tab() {
		$backups = $this->get_backups();
		?>
		<div class="wsk-card">
			<h2>Backups</h2>
			<p class="wsk-description">Website Stylekit saves a backup before every import. CSS is useful for moving styles through the normal Import tab. A backup file is different: it stores the exact Elementor data and can only be restored here.</p>

			<div class="wsk-backup-toolbar">
				<div>
					<strong>Automatic import backups</strong>
					<span class="wsk-hint">Keeping the latest <?php echo esc_html( self::MAX_BACKUPS ); ?> backups for this Elementor kit.</span>
				</div>
				<div class="wsk-backup-toolbar__actions">
					<button id="wsk-create-backup-btn" class="button">Create Manual Backup</button>
					<label class="button" for="wsk-upload-backup-input">Upload Backup</label>
					<input id="wsk-upload-backup-input" type="file" accept=".json,application/json" style="display:none;">
				</div>
			</div>

			<div id="wsk-backup-success" class="wsk-success" style="display:none;"></div>
			<div id="wsk-backup-error" class="wsk-error" style="display:none;"></div>

			<?php if ( empty( $backups ) ) : ?>
				<div class="wsk-empty-state">
					<strong>No backups yet</strong>
					<p>Apply an import or create a manual backup, and it will show up here.</p>
				</div>
			<?php else : ?>
				<div class="wsk-backup-list">
					<?php foreach ( $backups as $backup ) : ?>
						<?php
						$backup_id = $backup['id'] ?? '';
						$created_at = ! empty( $backup['created_at'] ) ? date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $backup['created_at'] ) ) : '';
						$mode = $backup['mode'] ?? 'backup';
						?>
						<div class="wsk-backup-item" data-backup-id="<?php echo esc_attr( $backup_id ); ?>">
							<div class="wsk-backup-item__main">
								<strong><?php echo esc_html( $backup['label'] ?? 'Backup' ); ?></strong>
								<span><?php echo esc_html( $created_at ); ?> · <?php echo esc_html( ucfirst( $mode ) ); ?></span>
							</div>
							<div class="wsk-backup-item__meta">
								<span><?php echo esc_html( (int) ( $backup['variable_count'] ?? 0 ) ); ?> variables</span>
								<span><?php echo esc_html( (int) ( $backup['class_count'] ?? 0 ) ); ?> classes</span>
							</div>
							<div class="wsk-backup-item__actions">
								<button class="button button-primary wsk-restore-backup-btn" data-backup-id="<?php echo esc_attr( $backup_id ); ?>">Restore</button>
								<button class="button wsk-view-backup-btn" data-backup-id="<?php echo esc_attr( $backup_id ); ?>">View</button>
								<button class="button wsk-download-backup-css-btn" data-backup-id="<?php echo esc_attr( $backup_id ); ?>">Download CSS</button>
								<button class="button wsk-download-backup-btn" data-backup-id="<?php echo esc_attr( $backup_id ); ?>">Download Backup</button>
								<button class="button wsk-delete-backup-btn" data-backup-id="<?php echo esc_attr( $backup_id ); ?>">Delete</button>
							</div>
							<div class="wsk-backup-viewer" style="display:none;">
								<textarea class="wsk-backup-viewer-output" readonly rows="18"></textarea>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render the About tab.
	 */
	private function render_about_tab() {
		?>
		<div class="wsk-about__body">
			<img
				src="<?php echo esc_url( WSK_PLUGIN_URL . 'assets/img/rino-profile.jpg' ); ?>"
				alt="Rino de Boer"
				class="wsk-about__photo"
				width="80"
				height="80"
			>

			<p>Hey, my name is Rino. I'm a Dutch web designer and I mainly work with Elementor.</p>

			<p>At some point I started noticing how much time I spent on setup. Not the creative part. The administrative part. Every new project: open a blank site, build the same colors, configure the same spacing, set the same typography. The same decisions, the same clicks, every single time.</p>

			<p>So I built <a href="https://websitestylekit.com" target="_blank" rel="noopener noreferrer">websitestylekit.com</a>. A place where you put together your design system once — your colors, your sizes, your fonts — and keep it ready to go.</p>

			<p>But a design system only means something when it lives inside your tools. That's what this plugin is for. You build your kit on websitestylekit.com, and this plugin gets it into your page builder.</p>

			<p>Right now it works with Elementor, because that's what I use. But websitestylekit.com doesn't belong to any one page builder. Divi, Bricks, whatever comes next — the kit stays the same. The importer just changes.</p>

			<p>I hope it saves you some of that setup time. That's really all it's supposed to do.</p>

			<img
				src="<?php echo esc_url( WSK_PLUGIN_URL . 'assets/img/rino-signature.svg' ); ?>"
				alt="Rino"
				class="wsk-about__signature"
				width="60"
				height="32"
				aria-hidden="true"
			>
		</div>
		<?php
	}

	/**
	 * Render the Changelog tab.
	 */
	private function render_changelog_tab() {
		?>
		<div class="wsk-changelog__body">

			<div class="wsk-changelog__release">
				<div class="wsk-changelog__release-header">
					<span class="wsk-changelog__version">v2.0</span>
					<span class="wsk-changelog__date"><?php esc_html_e( 'May 2026', 'websitestylekit' ); ?></span>
				</div>
				<p class="wsk-changelog__intro"><?php esc_html_e( 'A bigger CSS-first workflow for moving complete stylekits between Elementor sites.', 'websitestylekit' ); ?></p>
				<ul class="wsk-changelog__list">
					<li><?php esc_html_e( 'CSS import — paste Website Stylekit CSS and the plugin detects supported colors, font families, sizes, and classes automatically.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Import preview — see what will be added, updated, or skipped before applying changes.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Class import — import Elementor global classes from CSS framework exports and update matching class names.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Clearer import results — summaries now show colors, font families, size variables, classes, and warnings separately.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'CSS exports — export CSS variables only, or a full CSS framework with variables and Elementor global classes.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Cleaner export output — CSS is formatted with readable spacing and class exports no longer show Elementor scope prefixes.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Simplified import modes — removed the copy mode and kept merge or replace as the main choices.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Backups — automatically save backups before imports, with manual backup, upload, readable CSS preview, restore, CSS download, backup download, and delete actions.', 'websitestylekit' ); ?></li>
				</ul>
			</div>

			<div class="wsk-changelog__release">
				<div class="wsk-changelog__release-header">
					<span class="wsk-changelog__version">v1.0</span>
					<span class="wsk-changelog__date"><?php esc_html_e( 'April 2026', 'websitestylekit' ); ?></span>
				</div>
				<p class="wsk-changelog__intro"><?php esc_html_e( 'First release. Built to connect Elementor V4 design tokens with websitestylekit.com.', 'websitestylekit' ); ?></p>
				<ul class="wsk-changelog__list">
					<li><?php esc_html_e( 'Import colors — paste JSON from websitestylekit.com directly into Elementor V4 global color variables.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Import font sizes — paste CSS clamp values and they are stored as Elementor size variables.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Two import modes: smart merge or replace existing imported style types.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Export variables — export colors, sizes, and fonts as JSON or raw Elementor format.', 'websitestylekit' ); ?></li>
					<li><?php esc_html_e( 'Reorder utility — groups variables by type and assigns clean sequential order numbers.', 'websitestylekit' ); ?></li>
				</ul>
			</div>

		</div>
		<?php
	}

	/**
	 * Render the Support tab.
	 */
	private function render_support_tab() {
		?>
		<div class="wsk-support__body">
			<h2><?php esc_html_e( 'Found a bug?', 'websitestylekit' ); ?></h2>
			<p><?php esc_html_e( 'Website Stylekit is a free plugin. There is no official support, but if you run into a bug I would like to know about it so I can fix it.', 'websitestylekit' ); ?></p>
			<p><?php esc_html_e( 'The best place to report it is the WordPress support forum. Just describe what happened and I will take a look when I can.', 'websitestylekit' ); ?></p>
			<a href="https://wordpress.org/support/plugin/websitestylekit/" target="_blank" rel="noopener noreferrer" class="wsk-support__button">
				<?php esc_html_e( 'Go to support forum', 'websitestylekit' ); ?>
			</a>
		</div>
		<?php
	}
}

// Initialize.
Website_Stylekit::get_instance();
