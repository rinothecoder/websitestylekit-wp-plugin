(function($) {
	'use strict';

	var exportOutput = '';

	// ========================
	// Tab switching
	// ========================

	$('.wsk-header__link').on('click', function(e) {
		e.preventDefault();
		var tab = $(this).data('tab');

		$('.wsk-header__link').removeClass('wsk-header__link--active');
		$(this).addClass('wsk-header__link--active');

		$('.wsk-tab-panel').removeClass('active');
		$('.wsk-tab-panel[data-tab="' + tab + '"]').addClass('active');

		// Update URL hash without page reload.
		history.replaceState(null, '', '#' + tab);
	});

	// Restore tab from URL hash on page load.
	var hash = window.location.hash.replace('#', '');
	if (hash && $('.wsk-header__link[data-tab="' + hash + '"]').length) {
		$('.wsk-header__link[data-tab="' + hash + '"]').trigger('click');
	}

	// ========================
	// Import
	// ========================

	$('#wsk-import-btn').on('click', function() {
		var btn = $(this);
		var input = $('#wsk-import-input').val().trim();
		var mode = $('input[name="wsk_import_mode"]:checked').val();
		var varType = $('input[name="wsk_var_type"]:checked').val();

		if (!input) {
			$('#wsk-import-error').text('Please paste some data first.').show();
			return;
		}

		// Only validate as JSON if it doesn't look like CSS.
		if (!input.match(/(:root\s*\{|--[a-zA-Z0-9_-]+\s*:)/)) {
			try {
				JSON.parse(input);
			} catch (e) {
				$('#wsk-import-error').text('Invalid JSON: ' + e.message).show();
				return;
			}
		}

		btn.text('Importing...').prop('disabled', true);
		$('#wsk-import-error, #wsk-import-success').hide();

		$.post(wskData.ajaxUrl, {
			action: 'wsk_import_variables',
			nonce: wskData.nonce,
			json_input: input,
			mode: mode,
			var_type: varType,
		}, function(response) {
			btn.text('Import Variables').prop('disabled', false);

			if (response.success) {
				var imported = response.data.imported || 0;
				var updated = response.data.updated || 0;
				var typeLabel = varType === 'sizes' ? 'size variable' : 'color';
				var typeLabelPlural = varType === 'sizes' ? 'size variables' : 'colors';
				var parts = [];

				if (imported > 0) {
					parts.push(imported + ' ' + (imported !== 1 ? typeLabelPlural : typeLabel) + ' imported');
				}
				if (updated > 0) {
					parts.push(updated + ' ' + (updated !== 1 ? typeLabelPlural : typeLabel) + ' updated');
				}

				var msg = parts.length > 0 ? parts.join(', ') + '.' : 'No changes were needed.';
				$('#wsk-import-success').text(msg + ' Refresh the Elementor editor to see the changes.').show();
			} else {
				$('#wsk-import-error').text(response.data || 'Something went wrong.').show();
			}
		}).fail(function() {
			btn.text('Import Variables').prop('disabled', false);
			$('#wsk-import-error').text('Request failed. Check your connection.').show();
		});
	});

	// ========================
	// Reorder
	// ========================

	$('#wsk-reorder-btn').on('click', function() {
		var btn = $(this);

		btn.text('Reordering...').prop('disabled', true);
		$('#wsk-reorder-error, #wsk-reorder-success').hide();

		$.post(wskData.ajaxUrl, {
			action: 'wsk_reorder_variables',
			nonce: wskData.nonce,
		}, function(response) {
			btn.text('Reorder Variables').prop('disabled', false);

			if (response.success) {
				var total = response.data.total || 0;
				$('#wsk-reorder-success').text('Done! Reordered ' + total + ' variables. Refresh the Elementor editor to see the changes.').show();
			} else {
				$('#wsk-reorder-error').text(response.data || 'Something went wrong.').show();
			}
		}).fail(function() {
			btn.text('Reorder Variables').prop('disabled', false);
			$('#wsk-reorder-error').text('Request failed. Check your connection.').show();
		});
	});

	// ========================
	// Export
	// ========================

	$('#wsk-export-btn').on('click', function() {
		var btn = $(this);
		var format = $('input[name="wsk_format"]:checked').val();
		var filter = $('input[name="wsk_filter"]:checked').val();

		btn.text('Exporting...').prop('disabled', true);
		$('#wsk-export-error').hide();
		$('#wsk-export-result').hide();
		$('#wsk-copy-btn, #wsk-download-btn').hide();

		$.post(wskData.ajaxUrl, {
			action: 'wsk_export_variables',
			nonce: wskData.nonce,
			format: format,
			filter: filter,
		}, function(response) {
			btn.text('Export Variables').prop('disabled', false);

			if (response.success) {
				exportOutput = JSON.stringify(response.data, null, 2);
				$('#wsk-export-output').val(exportOutput);
				$('#wsk-export-result').show();
				$('#wsk-copy-btn, #wsk-download-btn').show();
			} else {
				$('#wsk-export-error').text(response.data || 'Something went wrong.').show();
			}
		}).fail(function() {
			btn.text('Export Variables').prop('disabled', false);
			$('#wsk-export-error').text('Request failed. Check your connection.').show();
		});
	});

	// Copy to clipboard.
	$('#wsk-copy-btn').on('click', function() {
		var btn = $(this);

		if (navigator.clipboard && exportOutput) {
			navigator.clipboard.writeText(exportOutput).then(function() {
				btn.text('Copied!');
				setTimeout(function() {
					btn.text('Copy to Clipboard');
				}, 2000);
			});
		} else {
			$('#wsk-export-output').select();
			document.execCommand('copy');
			btn.text('Copied!');
			setTimeout(function() {
				btn.text('Copy to Clipboard');
			}, 2000);
		}
	});

	// Download as JSON file.
	$('#wsk-download-btn').on('click', function() {
		if (!exportOutput) return;

		var blob = new Blob([exportOutput], { type: 'application/json' });
		var url = URL.createObjectURL(blob);
		var a = document.createElement('a');

		a.href = url;
		var filterName = $('input[name="wsk_filter"]:checked').val() || 'all';
		a.download = 'elementor-' + filterName + '-variables.json';
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
	});

})(jQuery);
